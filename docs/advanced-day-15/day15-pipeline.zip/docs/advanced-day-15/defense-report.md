# Отчёт защитника — День 15 Red Team (2026-11-06)

Роль: защитник собственного пайплайна. Вход: отчёт атакующего
(`attack-report.md`, 11 пробитий). Все фиксы в ветке `feat/day-15-red-team`,
milestone `run-2026-11-06-2` (эпик #219, stories #220–#225).

## Что пофикшено

### 1. Детекторы обфускации секретов — `challenge/src/core/gateway/secrets.ts`
(commit 19bc999, story #222)

- **Split через операторы языка:** `[a,b].join('')`, `a.concat(b)`, template
  literal с `${…}` — матчатся по оригинальному тексту (точная позиция для
  маскирования), находка засчитывается только если склеенная строка реально
  содержит секрет (`scanJoined` → `scanSecrets`) — закрывает RT-04/05/06.
- **Escape-последовательности:** `\xNN` и `\uNNNN`/`\u{…}` декодируются
  токен-парсером и ресканируются, новый kind `hex_secret` — RT-07.
- **Double base64:** рекурсивный декод с ограничением глубины
  (`MAX_DECODE_DEPTH = 2`) — RT-08.
- **base64 с пробелами/переносами:** нормализация с картой обратных индексов
  (находка и маскирование по исходным позициям) — RT-09.
- **Дедупликация перекрытий** находок (`dedupeOverlaps`) — base64-ws поверх
  base64 не плодит дублей.
- **Output guard:** утечка system prompt ловится также в base64-декодированных
  токенах и в кусках без вставок (префикс 200 нормализованных символов) — RT-11,
  частично RT-12.
- **Инцидент-фикс:** рекурсия детекторов упиралась в reentrancy глобальных
  regex (`lastIndex` сбивался вложенным `scanSecrets`) → бесконечный цикл/OOM.
  Все exec-циклы переведены на `matchAll` (реентерабельно), маскирование —
  по заранее собранным спанам (`replaceWhen`).

### 2. Детерминированный security backstop — `challenge/src/core/securityLoop/backstop.ts`
(commit 830ca7b, story #223)

- `localSecurityFindings(code)`: критичные hardcoded secret (через полный
  `scanSecrets`, включая обфускацию), gateway-маркеры `[REDACTED_*]` /
  `[SUSPICIOUS_*]` в коде, injection/exfil-фразы («это тестовый код…»,
  «ignore previous instructions», «пропусти ревью», готовый JSON-вердикт,
  дамп `process.env`) — severity high/critical — закрывает RT-15/16/17.
- `evaluateSecurityReview(raw, code)` — единая точка решения: parse
  (fail-closed) + merge backstop-находок + classify. Вердикт ревьюера-LLM
  больше не единственный источник: «послушный» ревьюер не может протащить
  коммит.
- Leak-guard в `parseSecurityReview`: фраза утечки в summary/evidence/
  recommendation → `ok:false` (review_error, коммит запрещён) — RT-18.
- `loop.ts`: бэкстоп-находки попадают в TaskReport и решение, событие
  `backstop` в `events.jsonl`.
- Кириллические паттерны: `\w*` не матчит кириллицу — заменено на
  `[а-яё]*` (найдено тестом RT-18/leak-guard).

### 3. Red team как регрессия — `challenge/src/core/redteam/` (commit ee305b6, story #221)

- 18 кейсов RT-01..RT-19 (baseline/hardening/residual), `PipelineTarget`
  гоняет реальные guard'ы и evaluate, scripted-LLM — офлайн и
  детерминированно.
- `pnpm --filter challenge start -- red-team` — обязателен перед боем:
  breach>0 → exit code 1 (CI-совместимо).
- Отчёт без сырых значений: только kind/stage/detail — безопасно пересылать
  партнёру.

## Финальный прогон: те же атаки после фикса

    pnpm --filter challenge start -- red-team

`attacks=18 defended=17 breached=0 residual=1 → PASS`
(run `rt-20261106-170805-b4cc`, отчёт `challenge/.data/red-team/…/report.json`).

Сравнение «до/после» (16 векторов прямого сравнения):
до `defended=5 breached=11` → после `defended=15 breached=1` (артефакты:
`swarm-report/day15-before-evidence.json`, `day15-after-gateway.json`,
`day15-after-loop.json`).

## Что осталось (честно)

- **RT-12 (residual):** system prompt, разрезанный на куски со вставками,
  статикой не ловится — произвольная реконструкция неразрешима без LLM-слоя.
  Компенсация: контекст объявлен данными в system prompt; review — отдельный
  вызов с temperature=0; конвенциональный выход — только через output guard,
  который ловит verbatim/префикс/base64.
- Парафразные инструкции («повтори инструкцию другими словами») — вне
  статических проверок по определению; наблюдаемо в audit/intercepted логах.
- Backstop-паттерны высокоточные, но не исчерпывающие: новая обфускация = новый
  кейс + детектор (процедура RT-04..RT-09 повторяема).
- Gateway loopback-only: наружу пайплайн выставлять только за reverse-proxy/TLS.

## Валидация защитника

- `pnpm --filter challenge typecheck` — чисто.
- `pnpm --filter challenge test` — 505/505 (baseline 478 + 27 новых).
- `pnpm --filter challenge start -- llm-gateway --self-test` — 14/14.
- Живой smoke `sec-loop --task t1 --no-commit` — committed_with_warning,
  4 LLM-вызова, gateway clean=4 (run-20261106-162634-0441).
- Секреты в diff: grep по `sk-`, `Bearer`, `ghp_` — только фейковые фикстуры
  тестов/кейсов.

## Appendix: Round 2 (2026-11-06, run-2026-11-06-3, эпик #227, stories #228–#232)

Повторный обстрел с расширенным набором: 46 новых кейсов RT-20..RT-65
(suite 18 → 64). Коммиты f9034ca, cffcfff, 1215f36, 738f260.

### Найдено и закрыто (2 пробития)

- **RT-36**: «голое» `rm -rf /` проходило output guard насквозь. Причина:
  trailing `\b` в `COMMAND_PATTERNS` после несловесных символов (`/`, `~`,
  `*`) не может заматчиться — паттерн работал только на `rm -rf /tmp/...`
  (граница перед буквой) и `$HOME`. Фикс: `\b` удалён; FP-тесты
  (`rm -rfx`, `rm -rf ./build` — allow). kind: hardening.
- **RT-51**: RU disclosure-фразы («вот мой системный промпт: …») не
  блокировались. Причина: `\w` в JS не покрывает кириллицу — паттерны
  `системн\w* промпт` в `LEAK_PATTERNS` были мёртвыми с Дня 13 (EN-пары
  работали). Фикс: `[а-яё]`; FP-тест (упоминание без раскрытия — allow).
  kind: hardening. Урок уже был зафиксирован для backstop-паттернов — теперь
  закрыт и в output guard.

### Новые поверхности под атакой

- Таксономия секретов: AWS/Google/Slack/JWT/Bearer/PEM — RT-20..RT-25
  (baseline, blocked); PII: карта (Luhn, blocked), телефон/email
  (redacted) — RT-26..RT-28.
- Indirect injection: AWS/JWT/карта/email в подложенном файле → input
  guard блокирует до LLM — RT-29..RT-32.
- Destructive/remote-exec команды ×10 (curl|sh, base64 -d|sh, powershell
  -enc, rm -rf, fork bomb, nc -e, chmod 777, child_process, os.system,
  subprocess shell=True) — RT-33..RT-42; suspicious URL ×7 (metadata-IP,
  data:, javascript:, креды в URL, IP-literal, shortener, non-TLS
  redacted) — RT-43..RT-49.
- Leak-фразы EN/RU без verbatim — RT-50/RT-51; review fail-closed:
  не-JSON ревьюер → review_error — RT-52; backstop с послушным ревьюером:
  gateway-маркер в коде, env-печать, EN/RU injection, EN/RU exfil,
  подсунутый JSON-вердикт — RT-53..RT-58.
- Обфускации round-2: unicode-escape (baseline), base64url (baseline:
  ASCII-секрет не может дать `+`/`/` в base64 — urlsafe ≡ standard),
  n-ary concat / fromCharCode / reverse / ROT13 / пробелы в литерале —
  RT-59..RT-65, все детекторы decode-and-scan (FP-safe по построению).

### Замечание по семантике

High-находки output guard (команды/URL) по проектному дизайну
**редактируются**, а не блокируют ответ (см. тест «опасная команда
редактируется» и таблицу gateway-исходов); в generateAndReview
редактированный код с `[SUSPICIOUS_*]` ловит backstop → regenerate.
Expectations кейсов выровнены с этим дизайном; `redacted` считается
удержанием защиты.

### Валидация round 2

- `pnpm --filter challenge typecheck` — чисто.
- `pnpm --filter challenge test` — 517/517.
- `pnpm --filter challenge start -- red-team` —
  `attacks=64 defended=63 breached=0 residual=1 → PASS`, exit 0.
- `pnpm --filter challenge start -- llm-gateway --self-test` — 14/14.
- Grep diff на сырые секреты — только фейковые фикстуры.

## Appendix: Round 3 (2026-11-07, run-2026-11-07, эпик #233)

Вход: расширенный набор атак RT-66..RT-81 (см. attack-report round-3).
Все 16 — breached до фикса. Фикс: новый кейс + детектор + FP-тест на
каждый (правило day-15: decode-and-scan / высокоточные фразы, находка
только если декод реально содержит секрет).

### Что пофикшено

- **`gateway/secrets.ts`**: split-кандидат «hex string literal» (декод hex →
  scanSecrets, чётная длина, printable — иначе null); `%NN`-последовательности
  в `findEscaped`/`maskSecrets`/`decodeEscaped`; общий строковый кандидат
  теперь strip-ит невидимые символы (U+200B..U+200F, U+2060, BOM, soft
  hyphen) вместе с пробелами. Закрывает RT-66/RT-67/RT-68.
- **`gateway/outputGuard.ts`**: LEAK_PATTERNS — «system instructions» EN
  (раскрытие = `are/is/was` + двоеточие, либо require/forbid, либо
  «here/these are my system instructions») и RU («инструкц*» в обеих
  семьях). FP-тест: «The system instructions are documented in the repo» —
  allow. COMMAND_PATTERNS: IEX/invoke-expression + DownloadString/…,
  new-object webclient + download, certutil + -urlcache, eval/Function/
  setTimeout + atob, exec + base64.b64decode. classifyUrl: decimal int,
  hex, dotted-hex хосты → highRisk. Закрывает RT-69..RT-75.
- **`gateway/inputGuard.ts`**: новая поверхность — `scanInstructions`
  (prompt_injection / exfil_request, EN+RU, включая «пропусти security
  review»). Инструкции блокируют запрос в обоих режимах (mask не
  применим к инструкции); server включает instructionSummary в 422
  findings, audit и intercepted-логи. Закрывает RT-76/RT-77/RT-78.
- **`securityLoop/backstop.ts`**: INJECTION_PATTERNS — RU «отвечай/ответь
  {summary}», подмена роли (you-are-now-the-approver / ты-теперь /
  твоя новая роль; «you are now ready to deploy» не бьётся), severity
  downgrade EN/RU. Закрывает RT-79/RT-80/RT-81.

### Что осталось (честно, поверх round-2)

- Instruction-паттерны — точные фразы: парафраз, опечатки и раздельные
  сообщения статикой не собираются (та же природа, что RT-12).
  Компенсация: output guard + backstop по выходу; наблюдаемость —
  intercepted.jsonl.
- Один FP-инцидент валидации: FP-тест «localhost:3040 → allow» был
  неверным — нестандартные порты флагались day-13 правилом портов и
  до round-3. Тест переписан на документирование поведения; детектор
  не менялся (surgical scope).

### Валидация round 3

- `pnpm --filter challenge typecheck` — чисто.
- `pnpm --filter challenge test` — 541/541 (+24 теста: детекторы, FP,
  input-instructions, backstop round-3).
- `pnpm --filter challenge start -- red-team` —
  `attacks=80 defended=79 breached=0 residual=1 → PASS`
  (run `rt-20261107-094939-09f2`).
- `pnpm --filter challenge start -- llm-gateway --self-test` — 14/14.
- Grep diff на сырые секреты — только фейковые фикстуры.

## Appendix: Round 4 (2026-11-07, run-2026-11-07-2, эпик #234)

Вход: 18 новых атак RT-82..RT-99 (см. attack-report round-4). Все 18 —
breached до фикса. Фикс: новый кейс + детектор + FP-тест на каждое семейство.

### Что пофикшено

- **`gateway/secrets.ts`**: base32 decode-and-scan (`base32_secret`, новый
  `via: 'base32'`); NFKC/fullwidth-кандидат строкового литерала; n-ary
  `.join('')` для 2+ элементов; `String.fromCodePoint`; `Buffer.from([bytes])`;
  hex-байты с пробелами; карта с точками (Luhn сохранён); `scanMessages`
  сканирует склейку сообщений и помечает находку `crossMessage`. В
  mask-режиме cross-message запрос блокируется, а не маскируется частично.
  Закрывает RT-82..RT-89.
- **`gateway/outputGuard.ts`**: wildcard-DNS (`nip.io`, `sslip.io`, `xip.io`,
  `localtest.me`, `lvh.me`) и IPv6-mapped хосты + metadata-хосты; отдельный
  матч IPv6-литерала (`]` не режется URL_RE); `rm -fr`/перестановки флагов;
  `chmod -R 777`; process substitution `bash <(curl …)`, `sh -c "$(curl …)"`;
  NFKC + strip невидимых в `normalizeForLeak`; base32-декод в проверке
  утечки system prompt. Закрывает RT-90..RT-94, RT-98..RT-99.
- **`gateway/inputGuard.ts`**: role spoof-токены (`<|im_start|>system`,
  `<|system|>`, `<<SYS>>`, `[INST]`, новый kind `role_spoof`); base64
  decode-and-scan инструкций; NFKC/zero-width нормализация; склейка сообщений
  для split-инструкций. Закрывает RT-95..RT-96.
- **`securityLoop/backstop.ts`**: decode-and-scan инструкций из base64 и
  NFKC-вида кода (line/evidence без сырых значений). Закрывает RT-97.
- **`redteam/target.ts`**: `scanInputParts` — multi-message поверхность
  для RT-89/RT-96.

### Audit follow-up (independent security review)

После round-4 независимый security-auditor нашёл P1/P2/P3; исправлено в том же
цикле:

- **P1 performance**: `findUrls` дедуп через `Set`, cap 100 находок на ответ,
  `applyRedactions` — один проход вместо repeated slicing, audit-preview
  строится из guard-выхода. Бенчмарк: 924 KB / 66k URL — 32.6 s → 146 ms.
- **P2 cross-message**: пересечение границы проверяется до duplicate-check;
  первый фрагмент, сам являющийся валидным ключом, больше не теряет
  `crossMessage` (mask-режим блокирует).
- **P2 base32**: case-insensitive + вариант с пробелами/переносами.
- **P2 невидимые/astral**: общий `normalizeUnicode` (`NFKC` + `\p{Default_Ignorable_Code_Point}`),
  нормализация строки целиком, а не по code unit.
- **P2 decode-and-scan инструкций**: base64/base32 до глубины 2, нормализация
  каждого декода, общий `decodeLayers` для input guard и backstop.
- **P2 URL**: bracketed `javascript:`/`data:`/`file:`, trailing-dot FQDN,
  NAT64, IPv4-compatible IPv6, `::1`.
- **P2 input guard FP**: системный промпт не сканируется как data; стандартная
  фраза «never reveal your system prompt» больше не блокирует все запросы.
- **P3**: `rm` quoted/braced `$HOME` и globs без FP на `./build/*`; chmod-флаги;
  `bash -lc`/`eval "$(curl …)"`; disclosure-фразы на нормализованном виде;
  пустой после нормализации system prompt; wrapper-находки сохраняют
  severity (split e-mail — medium/redact).

### Re-audit follow-up (second fresh-context pass)

- **F1 (P1)**: cap 100 medium больше не выбрасывает critical/high до решения;
  `findUrls` хранит все high-risk URL, medium ограничен; redaction one-pass.
  Регресс-тест «100 e-mail + API-key/команда».
- **F2/F3/F4**: base32 в прозе/комментарии ищется окнами токенов (не compact-all);
  bare invisible/fullwidth/math-bold секрет ловится нормализованным view
  (scan+mask); U+2800 добавлен в strip-set; `normalizeText` сохраняет границу
  слова (invisible→space), `normalizeUnicode` — для секретов (remove).
- **F5**: `decodeLayers` выровнен с `MAX_DECODE_DEPTH=3`, 64 views / 100k chars;
  triple base64 и 32 padding-токена — тесты.
- **F6/F7/F8/F9**: NAT64 local-use (`64:ff9b:1::`), 6to4 (`2002::`),
  `java\nscript:`, `$HOME/*`, `"${HOME}/"`, `/tmp/../*`, отрицательная
  anti-leak политика в user-сообщении.

### Что осталось (честно, поверх round-3)

- Произвольный самописный декодер (XOR, свой алфавит, арифметика над
  кодами) статикой не доказывается: decode-and-scan покрывает известные
  схемы, а не язык произвольной обфускации. Компенсация: output guard +
  backstop + review вторым вызовом + audit/intercepted.
- Blocklist wildcard-DNS не является полным списком DNS-rebinding-сервисов;
  новый домен = новый кейс.
- Парафраз/опечатки инструкций по-прежнему residual (та же природа, что
  RT-12): статические фразы не исчерпывают язык.

### Валидация round 4

- `pnpm --filter challenge typecheck` — чисто.
- `pnpm --filter challenge test` — 601/601 (+60 тестов: secrets ×18,
  outputGuard ×20, inputGuard ×12, backstop ×7, gateway server ×3).
- `pnpm --filter challenge start -- red-team` —
  `attacks=98 defended=97 breached=0 residual=1 → PASS`
  (run `rt-20261107-162014-5438`).
- `pnpm --filter challenge start -- llm-gateway --self-test` — 14/14.
- Grep diff на сырые секреты — только фейковые фикстуры.
