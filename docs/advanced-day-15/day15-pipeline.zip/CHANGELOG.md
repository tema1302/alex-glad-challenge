# Changelog

Хронология прохождения челленджа. Каждая запись содержит: полный текст задания,
что сделано, какие выводы, где посмотреть код.

---

## ADVANCED Day 15 — Red Team Challenge (2026-11-06)
**Ветка:** `feat/day-15-red-team` (loop run-2026-11-06-2, эпик #219)

**Задание (полный текст):**
> Подготовьте свой пайплайн к бою: проверьте gateway, execution loop, security
> step; напишите README (запуск, endpoint, вход/выход); откройте доступ
> партнёру. Обменяйтесь пайплайнами и ломайте друг друга: prompt injection,
> indirect injection, обход security review, утечка секрета мимо regex
> (base64, разбиение, комментарии). Итог: отчёт атакующего + отчёт защитника +
> пайплайн после hardening loop-run.

**Что сделано:**
- Верификация боеспособности: baseline 478/478 тестов, gateway self-test
  14/14, live smoke `sec-loop --task t1` (committed_with_warning, 4 LLM-вызова
  через gateway, run-20261106-162634-0441).
- Red team офлайн: `challenge/src/core/redteam/` — AttackTarget/PipelineTarget
  (реальные guards + evaluate, scripted-LLM), 18 атак RT-01..RT-19, runner с
  отчётом без сырых значений. CLI `red-team [--list]`.
- Gateway hardening (`challenge/src/core/gateway/secrets.ts`,
  `outputGuard.ts`): детекторы `[..].join('')`, `.concat()`, template literal
  с `${…}`, hex/unicode-escape, double base64 (глубина ≤2), base64 с
  пробелами/переносами; утечка system prompt в base64 и кусками без
  разделителей; дедупликация перекрытий; exec-циклы → matchAll (fix reentrancy
  OOM).
- Loop hardening (`challenge/src/core/securityLoop/backstop.ts`):
  детерминированный security backstop (секреты, `[REDACTED_*]`-маркеры,
  injection/exfil-фразы с FP-контролем) + `evaluateSecurityReview` — единая
  точка решения; leak-фраза в JSON ревью → fail-closed `review_error`;
  событие `backstop` в логах.
- README боя: `docs/advanced-day-15/README.md`; отчёты атакующего/защитника в
  том же каталоге.

**Результаты:**
- До hardening: 5/16 атак остановлено, 11 пробитий (join/concat/template/hex/
  double-base64/b64-split, system prompt в base64/кусками, review bypass ×3).
- После hardening: `attacks=18 defended=17 breached=0 residual=1 → PASS`
  (RT-12 — system prompt кусками с разделителями, осознанный residual).
- Тесты: 505/505 (было 478); gateway self-test 14/14.
- Red-team прогоны: `swarm-report/day15-before-evidence.json` (до),
  `challenge/.data/red-team/rt-20261106-*/report.json` (после).

### Round 2 — расширение red team (2026-11-06, run-2026-11-06-3, эпик #227)

- Сут расширен с 18 до 64 атак (RT-20..RT-65): таксономия секретов
  (AWS/Google/Slack/JWT/Bearer/PEM), PII (карта/телефон/email) на входе и
  выходе, 10 destructive-команд + 7 suspicious URL, leak-фразы EN/RU,
  review fail-closed (не-JSON ревьюер), backstop-кейсы с послушным ревьюером,
  обфускации round-2 (n-ary concat, `String.fromCharCode`, reverse, ROT13,
  пробелы в литерале, base64url, unicode-escape).
- Два реальных пробития найдены обстрелом и закрыты: RT-36 «голое» `rm -rf /`
  (dead-regex с `\b` после несловесных символов) и RT-51 RU disclosure-фразы
  (`\w` не покрывает кириллицу — паттерны не матчились с Дня 13).
- Детекторы round-2 — decode-and-scan, FP-safe по построению: находка только
  если расшифровка содержит секрет; FP-тесты на slug/фразы/rot13-junk.
- Итог: `attacks=64 defended=63 breached=0 residual=1 → PASS`; 517/517
  тестов; typecheck чисто; self-test 14/14. Коммиты f9034ca, cffcfff,
  1215f36, 738f260.

### Round 3 — защита + атаки перед боем с соперником (2026-11-07, run-2026-11-07, эпик #233)

- Сут расширен с 64 до 80 атак (RT-66..RT-81): plain-hex строка,
  percent-encoding, zero-width U+200B в литерале секрета, «system
  instructions» EN/RU, PowerShell IEX-cradle, `certutil -urlcache`,
  `eval(atob(…))` без секрета внутри, decimal/hex IP в https URL,
  prompt injection в пользовательском вводе EN/RU + подложенный файл
  с инструкцией без секретов, RU JSON-вердикт ревьюеру, подмена роли,
  занижение severity.
- Defense: `secrets.ts` — три decode-and-scan детектора (hex-string,
  %NN-последовательности, strip-невидимых); `outputGuard.ts` —
  instructions-leak EN/RU (раскрытие = двоеточие/предписание, FP-тест на
  «documented in the repo»), IEX/certutil/eval-atob паттерны,
  decimal/hex IP-хосты; `inputGuard.ts` — scanInstructions: инструкции-
  инъекции во вводе блокируются в обоих режимах (prompt_injection /
  exfil_request), находки идут в 422/audit gateway; `backstop.ts` —
  RU «отвечай {summary}», role reassignment, severity downgrade.
- Все 16 новых кейсов до фикса пробивали (breached), после — hardening.
- Итог: `attacks=80 defended=79 breached=0 residual=1 → PASS`; 541/541
  тестов; typecheck чисто; self-test 14/14. README дополнен battle
  playbook'ом для живого боя с партнёром.

### Round 4 — усиление защиты и атак перед боем (2026-11-07, run-2026-11-07-2, эпик #234)

- Сут расширен с 80 до 98 атак (RT-82..RT-99): fullwidth/NFKC, base32,
  3-элементный `.join('')`, `String.fromCodePoint`, `Buffer.from([bytes])`,
  hex-байты с пробелами, карта с точками, split секрета между сообщениями,
  wildcard-DNS SSRF (`nip.io`), IPv6-mapped metadata, `rm -fr`, `chmod -R`,
  `bash <(curl …)`, ChatML role spoof, base64-инструкция в файле, base64
  review bypass, zero-width system prompt echo, system prompt в base32.
- Defense: `secrets.ts` — base32/n-ary/fromCodePoint/Buffer/spaced-hex/NFKC
  decode-and-scan, cross-message скан; `outputGuard.ts` — wildcard-DNS и
  IPv6-mapped хосты, перестановки флагов destroy/chmod, process substitution,
  NFKC+strip в сравнении system prompt; `inputGuard.ts` — role spoof,
  base64 decode-and-scan инструкций, NFKC/zero-width, склейка сообщений;
  `backstop.ts` — decode-and-scan инструкций из base64/NFKC.
- Все 18 новых кейсов до фикса пробивали, после — hardening.
- Audit follow-up: P1 performance (cap/one-pass redaction, 32.6 s → 146 ms на
  924 KB), P2 cross-message boundary, case-insensitive base32, общий
  `normalizeUnicode`, многослойный decode-and-scan инструкций, bracketed
  URL-схемы/FQDN/NAT64, FP системного промпта; P3 command-варианты,
  disclosure-нормализация, severity wrapper-находок.
- Итог: `attacks=98 defended=97 breached=0 residual=1 → PASS`; 601/601
  тестов; typecheck чисто; self-test 14/14. Добавлен подробный
  `docs/advanced-day-15/battle-playbook.md` для боя с соперником.

---

## ADVANCED Day 13 — LLM Gateway (2026-11-04)
**Ветка:** `feat/llm-gateway-day-13` (loop run-2026-11-04, эпик #206)

**Задание (полный текст):**
> Поднимите прокси между пользователем и LLM: HTTP-сервер, который проверяет
> запрос и проксирует в OpenAI / Anthropic, логирует запросы/ответы для аудита.
> Input Guard: секреты (sk-, ghp_, AKIA), email, карты, телефоны; block или
> mask. Output Guard: сгенерированные секреты, утечка system prompt,
> подозрительные URL/команды. Минимум 10 тест-кейсов. Усиление: rate limiting
> на IP и cost tracking по токенам.

**Что сделано:**
- `challenge/src/core/gateway/` — `secrets`, `inputGuard`, `outputGuard`,
  `rateLimit`, `cost`, `auditLog`, `upstream`, `server`, `cases`.
- HTTP: `POST /v1/chat/completions`, `GET /healthz`, `GET /stats`; провайдеры
  OpenAI-compatible (DeepSeek/OpenRouter/OpenAI) и Anthropic Messages API.
- Input Guard: regex-детекторы ключей/ПДн, Luhn для карт, base64 и split
  (`"sk-" + "proj-abc"`), режимы `block`/`mask`.
- Output Guard: секреты и утечка system prompt → block; подозрительные URL и
  shell-команды → redact.
- Audit JSONL (`challenge/.data/gateway/audit.jsonl`,
  `intercepted.jsonl`) без сырых секретов; rate limit N/мин на IP; стоимость по
  usage и прайсу модели.
- CLI `llm-gateway` (`--port`, `--rate`, `--mode`, `--model`, `--self-test`);
  env — `GATEWAY_*`/`ANTHROPIC_*` в `.env.example`.

**Результаты:**
- Self-test: 14/14 passed; caught=11, missed=3 (2 чистых контроля + 16 цифр без
  Luhn — осознанный пропуск).
- 42 gateway-теста: secrets/input/output/rate/cost/audit/upstream/server.
- Live smoke: `/healthz` 200, секрет → 422 без вызова upstream, `/stats`
  `blockedInput=1`, audit/intercepted без сырого ключа.

**Код:** `challenge/src/core/gateway/**`, `challenge/src/cli.ts`,
`challenge/src/core/env.ts`, `.env.example`.
**Документы:** `docs/advanced-day-13/{README,test-cases,live-run}.md`.
**Риски:** эвристики (не DLP), один слой base64, нет стриминга, нет auth на
gateway (только loopback), audit-файлы без ротации.

---

## ADVANCED Day 14 — Execution Loop + Security Step (2026-11-06)
**Профиль:** изначально `business-feature`; corrective — loop-run с milestone
и issues. **Live-run:** `run-20261106-153805-a4a7` (локальный gateway, guard
`block`, model `deepseek-flash`).

**Задание (полный текст):**
> Возьмите execution loop из Недели 2: промпт → генерация → тесты → результат.
> Добавьте security step между генерацией и коммитом: после тестов отправьте
> код на security review вторым вызовом LLM с отдельным security-промптом.
> Critical/High → вернуть цикл на генерацию с фидбеком «исправь: … в строке N»;
> Medium/Low → пропустить с warning; чисто → коммит. Весь loop — через LLM
> Gateway Дня 3; зафиксировать, что gateway поймал/заблокировал, а что
> пропустил чистым. Security-промпт под стек: iOS (Keychain/ATS/pinning),
> Android (encrypted SharedPreferences/network config/root), общее (hardcoded
> secrets, PII в логах, HTTP, input validation). Проверить на 3 задачах:
> «сохрани токен авторизации», «добавь логирование всех запросов», «сделай
> запрос на API».

**Что сделано:**
- `challenge/src/core/securityLoop/` — gateway-клиент, generation + security
  prompt, JSON-парсер review с fail-closed, severity policy, static/command
  test runners, sandbox git commit, JSONL events/report.
- CLI `sec-loop`: локальный gateway (или внешний loopback), 4 demo-прогона на
  3 задачи, `--task/--max-attempts/--no-commit/--mode/--rate`.
- Security-промпт для `android`/`ios`/`web`/`generic`; Android-вариант —
  `docs/advanced-day-14/security-prompt.md`.
- Все LLM-вызовы — только `GatewayClient` → `POST /v1/chat/completions`;
  provider key не покидает gateway, external URL проверяется на loopback.
- Feedback: `[CRITICAL] строка 21: …`; previous code маскируется перед retry;
  gateway input block на review превращается в security feedback с локальной
  строкой.

**Результаты:**
- Live: 15 LLM-вызовов (12 clean, 2 redacted, 1 blocked input), 3 sandbox
  commit с warning, 0 errors; 10 warning-findings.
- Security review поймал 1 critical + 4 high за попытки: plaintext DataStore,
  BODY-логирование Authorization/тел, HTTP base URL с Bearer, cleartext для
  auth — все возвращены на генерацию.
- Gateway поймал T2 leak-probe (jwt/bearer/email/base64, HTTP 422, upstream не
  вызван) и отредактировал HTTP URL в T3 (5 × suspicious_url).
- «Не заблокировали оба»: только Medium/Low (T1 3 low; T2 2 medium + 1 low;
  T3 2 medium + 2 low) — commit с warning по политике; полностью
  необнаруженных Critical/High нет.
- Проверки: typecheck OK; challenge 478/478; focused 64/64; gateway self-test
  14/14; `scanSecrets` по логам/sandbox = 0; абсолютных путей в логах нет.

**Трекер:** milestone `run-2026-11-06`, эпик #218, stories #211–#216,
process-retro #217.
**Skill:** `.omp/skills/security-execution-loop/SKILL.md` (добавлен в
`AGENTS.md` §11); фиксирует loop-run и tracker-before-edit для будущих
security-step задач.

**Процесс:** изначально задача была выполнена как `business-feature` — без
milestone/epic/stories, потому что в запросе не было токена `loop-run` и
существующего milestone. Это ошибка интерпретации для задачи, которая прямо
описывает execution loop; corrective — skill, ретроспективный milestone и
issues #211–#218, зафиксировано в #217.

**Код:** `challenge/src/core/securityLoop/**`, `challenge/src/cli.ts`,
`challenge/src/core/index.ts`.
**Документы:** `docs/advanced-day-14/{README,test-cases,live-run,security-prompt}.md`,
`docs/advanced-day-14/logs/**`.
**Риски:** LLM-review недетерминирован; gateway — эвристики, не SAST/DLP;
Android demo не компилируется (нет JDK/SDK), тестовый шаг — static
lint/contract; sandbox commit не попадает в историю проекта.

---

## День 1 — Первый запрос к LLM через API
**Дата:** 2026-06-01

**Задание (полный текст):**
> Напишите минимальный код, который:
> - отправляет запрос в LLM через API
> - получает ответ
> - выводит его в консоль или простой интерфейс (CLI / Web)
>
> Результат: код, который отправляет запрос в LLM через API и получает ответ.
> Формат: видео + код.

**Сделано:**
- В архиве (`1-day/index.ts`): фрагмент TS-клиента в контексте Next.js-приложения.
- TS-порт (`challenge/src/demos/day-01.ts`): автономный скрипт через
  `@challenge/core::LlmClient`.

**Выводы:**
- OpenAI-совместимый `/chat/completions` работает одинаково и для DeepSeek,
  и для OpenRouter — отличается только base_url и ключ.
- Минимальный запрос: `{model, messages}`.

**Код:** `challenge/src/demos/day-01.ts`

---

## День 18 — MCP-инструмент с фоновым выполнением и Telegram-напоминаниями
**Дата:** 2026-06-27
**Ветка:** `day-18`

**Задание (полный текст):**
> Создать MCP-инструмент с отложенным фоновым/периодическим выполнением,
> который работает 24/7. Реализовать TODO-планировщик с напоминаниями
> в Telegram: задачи с настраиваемым интервалом повторения (ежечасно,
> ежедневно, еженедельно).

**Сделано:**
- MCP HTTP-сервер (`day-18-server.ts`) с 8 тулзами:
  `add_todo`, `list_todos`, `complete_todo`, `dismiss_todo`, `delete_todo`,
  `send_summary`, `call_remote_tool`, `list_remote_tools`.
- SQLite-хранилище тудушек (`TodoDb`) с поддержкой recurring:
  `daily` (раз в день), `weekly` (день недели), `hourly` (каждые N часов).
- Фоновый цикл: каждые 60с проверяет due-задачи и отправляет в Telegram.
- **Регулярный ежедневный summary** (`runDailySummary`): фоновый таймер каждые
  5 мин проверяет — если локальный час ≥ `SUMMARY_HOUR` (по умолчанию 9) и сегодня
  сводка ещё не отправлялась (дата в `todo_meta.last_daily_summary_date`), шлёт
  список всех pending-задач в Telegram одним сообщением. Guard по дате убирает
  дубль в тот же день; пустой список не отправляется. Заменил старый «spam-loop»
  (отправка due-задач каждые 60с), который мешал жить.
- Telegram-отправка через HTTP-прокси (gost → socks5) + `undici.ProxyAgent`.
- Systemd-сервисы на VPS: `mcp-server` (scheduler) + `gost-proxy` (HTTP↔socks5).
- MCP endpoint доступен через Caddy: `https://api.memo7.ru/mcp`.

**Параметры:**
- Провайдер: Telegram Bot API через HTTP-прокси (GOST).
- База: `challenge/.data/todos.sqlite`.
- Прокси: `gost -L http://127.0.0.1:3128 -F socks5://...` (systemd `gost-proxy`).
- Интервал: проверка daily-summary каждые 5 мин, реальная отправка — раз в день
  после `SUMMARY_HOUR` (по умолчанию 9). `SUMMARY_HOUR` задаётся в `.env` (0–23).

**Архитектура:**
```
Компьютер (curl) ──→ VPS: Caddy :443 → MCP :3001
                                       │
                                       ├── SQLite (todos.sqlite)
                                       ├── daily-summary таймер (5 мин → раз в день)
                                       └── Telegram Bot API
                                            └── gost :3128 → socks5 → api.telegram.org
```

**Примеры использования (curl с компьютера):**
```powershell
# Добавить напоминание каждые 2 часа
curl https://api.memo7.ru/mcp -X POST -H "Content-Type: application/json" `
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"add_todo","arguments":{"text":"Проверить почту","recurring":"hourly","interval_hours":2}}}'

# Ежедневная задача
curl https://api.memo7.ru/mcp -X POST -H "Content-Type: application/json" `
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"add_todo","arguments":{"text":"Сделать зарядку","recurring":"daily"}}}'

# Посмотреть все задачи
curl https://api.memo7.ru/mcp -X POST -H "Content-Type: application/json" `
  -d '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"list_todos","arguments":{}}}'

# Отправить сводку вручную
curl https://api.memo7.ru/mcp -X POST -H "Content-Type: application/json" `
  -d '{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"send_summary","arguments":{}}}'
```

**Выводы:**
- socks5-туннель напрямую (SocksClient + TLS) работал в изоляции но завис в tsx+systemd —
  не удалось найти причину, переключился на gost HTTP-прокси.
- undici 8.x несовместим с Node 22 встроенным fetch (invalid onRequestStart) —
  нужен undici 7.x.
- `Connection: close` + Content-Length парсинг — обязательны для raw HTTP поверх TLS,
  иначе `end` event не приходит.
- MCP JSON-RPC протокол — простой и рабочий способ дать CLI-доступ к серверным
  тулзам без отдельного SDK.

**Код:**
- `challenge/src/core/todoDb.ts` — SQLite БД тудушек.
- `challenge/src/core/agents/telegram.ts` — отправка в Telegram.
- `challenge/src/demos/day-18-server.ts` — MCP HTTP-сервер с 8 тулзами.
- `challenge/src/demos/day-18.ts` — оригинальный день 18 (демо).
- Команда: `pnpm --filter challenge start -- scheduler`

---

## День 19 — Композиция MCP-инструментов
**Дата:** 2026-06-27
**Ветка:** `day-19`

**Задание (полный текст):**
> Создайте несколько MCP-инструментов, например: `search`, `summarize`, `saveToFile`.
> Реализуйте пайплайн: первый инструмент получает данные, второй обрабатывает,
> третий сохраняет результат. Проверьте: автоматическое выполнение цепочки и
> корректность передачи данных между инструментами.
> Результат — автоматический пайплайн из нескольких MCP-инструментов.
> Формат — видео + код.

**Продукт (по задумке автора челленджа):** юзер пишет запрос в REPL/CLI
(например: «просканируй последние 200 сообщений в чате "факты в чате" и пришли
отчёт») — после этого агент сам гонит цепочку MCP-тулов. Это НЕ демка с
авто-прогоном: триггер всегда юзер, агент действует по его запросу. Bot API не
умеет читать историю — для скана чата нужен MTProto userbot (api_id/api_hash/session).

**Сделано:**
- 3 инструмента добавлены на ЕДИНЫЙ работающий сервер (`day-18-server.ts` =
  api.memo7.ru), а не отдельный день-сервер и не демка:
  `scan_chat_messages` (MTProto, получить) → `analyze_messages` (детерминированный
  отчёт по авторам/терминам/ссылкам, без LLM) → `send_to_chat` (отправить отчёт в
  `TG_CHAT_ID` через Bot API).
- `core/agents/telegramScan.ts` — MTProto-клиент (GramJS, StringSession из env):
  connect/disconnect, `scanChatMessages(chat, limit)` (по @username / id /
  заголовку диалога), `analyzeMessages` — чистая функция.
- Точка входа для юзера — команда `agent` в CLI и `/agent` в REPL, общая через
  `runAgentRequest` (`core/mcpAgentLoop.ts`). Цепочку вызывает сама LLM в цикле
  `CALL/RESULT`; данные протекают через кеш последнего скана и контекст модели.
- `runAgentLoop` вынесен из `day-17.ts` в `core/mcpAgentLoop.ts` (+ `runAgentRequest`,
  `DEFAULT_AGENT_SYSTEM`), переиспользуется day-17 и `/agent`.

**Параметры:**
- MTProto (скан истории): `TG_API_ID`, `TG_API_HASH`, `TG_SESSION` (userbot).
- Доставка отчёта: `TG_BOT_TOKEN`, `TG_CHAT_ID`, `HTTPS_PROXY` (Bot API, как day-18).

**Выводы:**
- Композиция тулзов — это агентский цикл: LLM сама решает порядок, сервер даёт
  детерминированные шаги. Поэтому отдельной «демки дня» нет — вход даёт юзер.
- Чтение истории Telegram — только MTProto; Bot API годится лишь для отправки.
- «Обработка» (analyze) сделана чистой функцией без LLM — сервер не зависит от
  модели; 200 сообщений идут в серверный кеш, а не в контекст LLM.

**Код:**
- `challenge/src/core/agents/telegramScan.ts` — MTProto-сканер + анализ.
- `challenge/src/core/mcpAgentLoop.ts` — цикл tool-calling + `runAgentRequest`.
- `challenge/src/demos/day-18-server.ts` — +3 тула скан-пайплайна на живом сервере.
- Команды: `pnpm --filter challenge start -- agent "<запрос>"`, в REPL — `/agent <запрос>`.

---

## День 20 — Orchestration MCP: «Брифинг дня»
**Дата:** 2026-06-28
**Ветка:** `day-20`

**Задание (полный текст):**
> Зарегистрируйте несколько MCP-серверов. Сделайте, чтобы:
> - агент выбирал нужный инструмент;
> - корректно маршрутизировал запросы;
> - выполнял длинный флоу взаимодействия.
> Проверьте:
> - сценарий с инструментами с РАЗНЫХ серверов;
> - корректность выбора и порядка вызовов.
> Результат: длинный флоу с несколькими MCP-серверами и инструментами.

**Продукт:** «Брифинг дня» для тимлида-отца-фаната. Триггер — юзер (команда
`day-20`); агент сам собирает сводку: дата + заметки из Obsidian-vault
(+ опционально web) → записывает заметку «Брифинг <дата>» обратно в vault.

**Сделано:**
- Два MCP-сервера в одном персистентном процессе (`day-20-server.ts`, деплоится
  как сервис — не демка и не in-process mock):
  - `obsidian-mcp` :3020 — `read_note` / `search_notes` / `create_note` над vault
    (`.data/vault/*.md`, filesystem, без плагина Obsidian и без Local REST API);
  - `world-mcp` :3021 — `get_current_time` (часы сервера) + `fetch_url` (web).
- `core/mcpOrchestrator.ts` — кросс-серверный роутер: подключается к N серверам,
  мержит их инструменты в один список, каждый `CALL` адресует на сервер-владелец.
  Обобщение односерверного `mcpAgentLoop`; на cap-hit делает forced final summary,
  иначе «ответом» остался бы сырой CALL последней итерации.
- `demos/day-20.ts` — тонкий клиент (как `day-18.ts`): коннект к обоим серверам,
  агентский цикл, trace маршрутизации. URL'ы через env `OBSIDIAN_MCP_URL` / `WORLD_MCP_URL`.
- CLI: `day-20-server` (поднять серверы), `seed-vault` (опциональные примеры заметок).
- Текстовый протокол `CALL/RESULT` (как day-17/19) — надёжнее нативного tools-API.

**Параметры:**
- LLM: `DEEPSEEK_API_KEY` / `OPENROUTER_API_KEY` (как везде).
- Серверы: `OBSIDIAN_MCP_URL` (по умолч. `http://localhost:3020/mcp`),
  `WORLD_MCP_URL` (`http://localhost:3021/mcp`); порты — `--obsidian-port` / `--world-port`.
- Vault: `OBSIDIAN_VAULT_DIR` (по умолч. `.data/vault`).

**Выводы:**
- Кросс-серверная оркестрация = агентский цикл над объединённым списком тулзов:
  шаг N на сервере A, шаг N+1 на сервере B — порядок выбирает модель, адрес — роутер.
  Замер прогона: `get_current_time` (world) → `read_note`/`search_notes` (obsidian)
  → `create_note` (obsidian).
- Obsidian как домен = filesystem-MCP над `.md`, без плагина/REST API — vault это
  просто папка.
- Промпт НЕ должен bait'ить ненадёжный web (Google JS-gate выдаёт бесполезный HTML),
  если данные уже есть в vault — иначе агент зацикливается на `fetch_url`.

**Код:**
- `challenge/src/core/mcpOrchestrator.ts` — мульти-серверный роутер.
- `challenge/src/demos/day-20-server.ts` — персистентный процесс (2 MCP-сервера).
- `challenge/src/demos/day-20-obsidian-server.ts` — vault MCP + сид.
- `challenge/src/demos/day-20-world-server.ts` — time + fetch MCP.
- `challenge/src/demos/day-20.ts` — клиент/демо.
- Команды: `pnpm --filter challenge start -- day-20-server` (поднять),
  `pnpm --filter challenge start -- day-20` (брифинг), `... seed-vault` (опционально).

---

## День 2 — Формат ответа
**Дата:** 2026-06-02

**Задание (полный текст):**
> Отправьте один и тот же запрос, но:
> - добавьте явное описание формата ответа
> - добавьте ограничение на длину ответа
> - добавьте условие завершения ответа (stop sequence или явную инструкцию)
>
> Сравните ответы: без ограничений vs с ограничениями.
> Результат: один и тот же запрос с разным уровнем контроля ответа через API.
> Формат: видео + код.

**Сделано:**
- Без ограничений, JSON-формат, stop-sequence + `max_tokens=60`.

**Выводы:**
- Явное описание формата в промпте надёжнее, чем параметр `stop`.
- `max_tokens` пригодится для дня 8 (токены), но жесткий лимит обрезает ответ
  посередине мысли.

**Код:** `challenge/src/demos/day-02.ts`

---

## День 3 — Разные способы рассуждения
**Дата:** 2026-06-05

**Задание (полный текст):**
> Возьмите одну задачу (логическую, алгоритмическую или аналитическую).
> Решите её через API четырьмя способами:
> 1. получите прямой ответ без дополнительных инструкций
> 2. добавьте в промпт инструкцию: «решай пошагово»
> 3. попросите модель сначала составить промпт для решения задачи, а затем
>    используйте его
> 4. создайте в промпте группу экспертов (например: аналитик, инженер, критик)
>    и получите решение от каждого
>
> Сравните: отличаются ли ответы, какой способ дал наиболее точный результат.
> Результат: несколько решений одной задачи и их сравнение.
> Формат: видео + код.

**Сделано:**
- Прямой ответ, "думай пошагово", мета-промпт, группа экспертов.

**Выводы:**
- "Пошагово" даёт самый структурированный и проверяемый ответ.
- Мета-промпт полезен, когда задача размытая — модель сама уточняет себя.

**Код:** `challenge/src/demos/day-03.ts`

---

## День 4 — Температура
**Дата:** 2026-06-07

**Задание (полный текст):**
> Выполните один и тот же запрос с параметрами:
> - temperature = 0
> - temperature = 0.7
> - temperature = 1.2
>
> Сравните ответы по: точности, креативности, разнообразию.
> Сформулируйте: для каких задач лучше подходит каждая настройка.
> Результат: примеры ответов с разной температурой и выводы по их использованию.
> Формат: видео + код.

**Сделано:**
- Три прогона, выводим рядом.

**Выводы:**
- 0 — для фактических ответов и кода.
- 0.7 — слоганы, краткие тексты, баланс.
- 1.2 — брейншторм, диверсификация идей; иногда рвёт логику.

**Код:** `challenge/src/demos/day-04.ts`

---

## День 5 — Версии моделей
**Дата:** 2026-06-07

**Задание (полный текст):**
> Выполните один и тот же запрос:
> - на слабой модели
> - на средней модели
> - на сильной модели
> (например: из начала, середины и конца списка HuggingFace)
>
> Замерьте: время ответа, количество токенов, стоимость (если модель платная).
> Сравните: качество ответов, скорость, ресурсоёмкость.
> Результат: короткий вывод о различиях между моделями + ссылки.
> Формат: видео + код.

**Сделано:**
- На OpenRouter: `gpt-4o-mini`, `gemini-2.0-flash`, `claude-3.5-sonnet`.
- Замеряем время и токены из `usage`.

**Выводы:**
- Слабые модели быстрее и дешевле, но путаются в многошаговых рассуждениях.
- На длинных промптах расход токенов растёт нелинейно — важно для дня 8.

**Код:** `challenge/src/demos/day-05.ts`

---

## День 6 — Первый агент
**Дата:** 2026-06-09

**Задание (полный текст):**
> Реализуйте простого агента, который:
> - принимает запрос пользователя
> - отправляет его в LLM через API
> - получает ответ
> - выводит результат в вашем интерфейсе
> (простой чат, CLI или web, запросы через HTTP-клиент)
>
> Важно:
> - агент должен быть отдельной сущностью, а не просто один вызов API
> - логика запроса и ответа должна быть инкапсулирована в агенте
>
> Результат: агент принимает запрос и корректно вызывает LLM через API.
> Формат: видео + код.

**Сделано:**
- `class Agent` с методом `say`, хранит system + history.
- REPL через `node:readline/promises`: ввод пользователя -> LLM -> ответ.

**Выводы:**
- Логика запроса инкапсулирована в агенте, UI ничего не знает про HTTP.
- Этот агент — основа для всех последующих дней (контекст, токены, ветки).

**Код:** `challenge/src/demos/day-06.ts`

---

## День 7 — Сохранение контекста
**Дата:** 2026-06-10

**Задание (полный текст):**
> Добавьте агенту сохранение контекста:
> - храните историю диалога (messages) в JSON или SQLite
> - при перезапуске агента загружайте историю обратно
> - продолжайте диалог так, как будто агент не выключался
>
> Проверьте на практике:
> - начните диалог
> - перезапустите приложение
> - продолжите диалог и убедитесь, что агент помнит прошлые сообщения
>
> Результат: агент, который сохраняет и восстанавливает контекст между запусками.
> Формат: видео + код.

**Сделано:**
- `day-07-history.json` рядом с бинарником.
- `loadHistory` + `saveHistory` через `node:fs/promises` вокруг каждого хода.

**Выводы:**
- JSON хорош для демо; на проде нужен SQLite (см. день 9 — compression).
- Восстановление работает, только если системный промпт детерминирован.

**Код:** `challenge/src/demos/day-07.ts`

---

## День 8 — Работа с токенами
**Дата:** 2026-06-11

**Задание (полный текст):**
> Добавьте в код агента подсчёт токенов:
> - для текущего запроса
> - для всей истории диалога
> - для ответа модели
>
> Сравните:
> - короткий диалог
> - длинный диалог
> - диалог, который превышает лимит модели
>
> Покажите: как растёт стоимость/токены по мере диалога, что ломается при
> переполнении.
>
> Результат: код, который считает токены и показывает, как они влияют на поведение.
> Формат: видео + код.

**Сделано:**
- Используем поле `usage` из ответа API.
- Копим `cum: Usage` по ходам.

**Выводы:**
- На длинной истории `prompt_tokens` растёт линейно — это главный аргумент
  за compression (день 9) и windowing (день 10).
- Без локального tokenization точный подсчёт невозможен — `usage` единственный
  честный источник.

**Код:** `challenge/src/demos/day-08.ts`

---

## День 9 — Управление контекстом: сжатие истории
**Дата:** 2026-06-11

**Задание (полный текст):**
> Реализуйте механизм управления контекстом:
> - храните последние N сообщений «как есть»
> - остальное заменяйте summary (например каждые 10 сообщений)
> - храните summary отдельно и подставляйте его в запрос вместо полной истории
>
> Сравните:
> - качество ответов без сжатия
> - качество ответов со сжатием
> - расход токенов до/после
>
> Результат: агент, который работает с компрессией истории и экономит токены.
> Формат: видео + код.

**Сделано:**
- `summarize()` отдельным вызовом LLM.
- Пересоздаём summary каждые K сообщений, подставляем как `system`.

**Выводы:**
- Экономия на `prompt_tokens` видна сразу после первой компрессии.
- Качество ответа слегка падает, если summary слишком агрессивно сжало факты —
  отсюда мотивация для Sticky Facts (день 10).

**Код:** `challenge/src/demos/day-09.ts`

---

## День 10 — Управление контекстом: разные стратегии (без summary)
**Дата:** 2026-06-14

**Задание (полный текст):**
> Реализуйте в агенте 3 разных стратегии управления контекстом (минимум),
> и переключатель между ними:
>
> Стратегия 1: Sliding Window
> - храните только последние N сообщений
> - всё остальное отбрасывайте
>
> Стратегия 2: Sticky Facts / Key-Value Memory
> - введите отдельный блок "facts" (ключ-значение), который хранит важные данные
>   из диалога (например: цель, ограничения, предпочтения, решения, договорённости)
> - обновляйте facts после каждого сообщения пользователя
> - в запрос отправляйте: facts + последние N сообщений
>
> Стратегия 3: Branching (ветки диалога)
> - сохраните checkpoint в диалоге
> - создайте 2 ветки от одного места
> - продолжите диалог в каждой ветке независимо
> - переключайтесь между ветками
>
> Протестируйте на одном и том же сценарии (например: "собираем ТЗ 10–15
> сообщений"): прогоните сценарий на каждой стратегии, сравните ответы и
> поведение.
>
> Сравните: качество ответа, стабильность (не теряет ли важные детали),
> расход токенов, удобство для пользователя.
>
> Результат: агент с 3 стратегиями управления контекстом
> (Sliding Window / Facts / Branching) + сравнение результатов.
> Формат: видео + код.

**Сделано:**
- Три класса, реализующих `ContextStrategy` из `@challenge/core`.
- Демо с одним и тем же сценарием (сбор ТЗ) на каждой стратегии.
- Branching: `checkpoint(label)` + `switchTo(id)`.

**Выводы:**
- Sliding — самый дешёвый, но теряет факты.
- Sticky Facts — лучший баланс, если правила извлечения фактов адекватные.
- Branching незаменим для "что если" сценариев и A/B тестинга промптов.

**Код:** `challenge/src/demos/day-10.ts`

---

## День 11 — <заглушка>
**Дата:** TBD

**Задание:**
> TBD

**Сделано:**
- (заполняется при получении задания)

**Выводы:**
- TBD

**Код:** `challenge/src/demos/day-11.ts` (ветка `day-11`)

---

## Feature: блог-агенты для канала «Иди на факты глянь»
**Дата:** 2026-06-17
**Ветка:** `feature/blog-agents`

**Цель:** автоматизировать ежедневную подготовку постов для футбольного
Telegram-канала. Три агента в одном pipeline: сбор новостей → написание поста
в авторском стиле → фактчекинг.

**Что сделано:**
- Хранилище: SQLite через `node:sqlite` (Node 24+, без нативных сборок).
  Таблицы `news`, `posts`, `style_samples` с UNIQUE-индексами против дублей.
- RSS-загрузчик: sports.ru, championat.com, BBC Sport (через `fast-xml-parser`).
- Агент 1 (NewsFetcher): LLM-выбор top-K хайповых из неиспользованных.
- Агент 2 (PostWriter): few-shot на 5 случайных образцах стиля канала.
- Агент 3 (FactChecker): JSON-verdict, сверка фактов с источником.
- CLI: `news`, `seed-style`, `db-stats` с флагами `--hours`, `--top`, `--for`.
- Документация: раздел про хранение контекста, cron для Windows/Linux.

**Параметры:**
- Провайдер: DeepSeek (через `.env`).
- Источник стиля: 13 реальных постов канала (залиты через `seed-style`).
- Хранилище: `challenge/.data/blog.sqlite` (в `.gitignore`).

**Smoke-результат** (реальный прогон):
- Агент 1: выбран топ-3 (Роналду-ЧМ, Скалони-Месси, Англия-Хорватия).
- Агент 2: пост про Скалони, 219 символов, с шапкой/CAPS/иронией/подписью.
- Агент 3: `verdict: ok`, «Пост полностью соответствует источнику».

**Выводы:**
- `node:sqlite` подходит для локальных cron-агентов без боли с нативными сборками
  (`better-sqlite3` требует ClangCL toolchain на Windows).
- Строгий JSON-промпт требует: явный пример, требование «первый символ ответа
  — `[`», `maxTokens >= 2000` для больших промптов, толерантный парсер
  (устойчив к markdown-обёртке и обрыву).
- Few-shot на 5 случайных образцов стиля даёт удовлетворительный результат;
  для проде можно расширить до 10-15 и/или кластеризовать по типам постов.

**Код:**
- `challenge/src/core/db.ts` — слой SQLite.
- `challenge/src/core/agents/{rss,newsFetcher,postWriter,factChecker,pipeline,seed}.ts`
- `challenge/src/data/style-samples.json` — 13 образцов стиля.
- Команды в `challenge/src/cli.ts`: `news`, `seed-style`, `db-stats`.

---

## День 21 — Индексация документов
**Дата:** 2026-07-01

**Задание (полный текст):**
> Возьмите набор документов (README / статьи / код / pdf → текст), минимум 20–30
> страниц суммарно (или эквивалент в коде). Реализуйте пайплайн индексации:
> разбиение на чанки (chunking), генерация эмбеддингов, сохранение индекса
> (FAISS / SQLite / JSON).
> Усиление: метаданные к каждому чанку (source, title/file, section, chunk_id) и
> минимум 2 стратегии chunking (фиксированный размер / по структуре) — сравнить.

**Правило дня 21+:** только локальные модели. Эмбеддинги — локальный эндпоинт
(`LOCAL_EMBED_*`), внешний сеть-запрос к онлайн-моделям запрещён.

**Сделано:**
- `core/rag/` — подсистема RAG: `types`, `loader`, `chunker`, `embedder`, `store`,
  `pipeline`.
- `loader.ts` — рекурсивное чтение `.md/.txt/.json` и `.ts/.js` (код как текст).
  PDF без сторонней dep не читается — допустим «эквивалент в коде».
- `chunker.ts` — две стратегии:
  - `fixed` — по размеру (`size`/`overlap`, по границам строк/слов).
  - `structure` — по заголовкам markdown (`#..######`, путь раздела); для кода —
    один чанк на файл.
  - Метаданные на каждый чанк: `source`, `title`, `section`, `chunkId`.
- `embedder.ts` — `HttpEmbedder` → POST на локальный `/embeddings`
  (OpenAI-совместимый: Ollama/LM Studio/vLLM).
- `store.ts` — `RagStore` через `node:sqlite` (`challenge/.data/rag.sqlite`),
  таблица `rag_chunks` с метаданными + embedding (JSON), brute-force косинус.
- Демо `day-21.ts`: индексирует `src/data/rag-sample/`, печатает таблицу
  сравнения стратегий (чанков / мин-сред-макс длина / размерность).
- CLI: `rag index [path] [--strategy ...]`.

**Выводы:**
- SQLite + JSON-колонка векторов + JS-косинус достаточно для сотен чанков без
  нативного FAISS/`faiss-node` (что нарушило бы инвариант «без внешних нативных
  драйверов»).
- `structure` даёт меньше, но смысловых чанков (по разделам); `fixed` —
  равномерных по размеру. Выбор зависит от корпуса: документация → structure,
  «простыня» текста → fixed.
- Локальные эмбеддинги (Ollama/LM Studio `/v1/embeddings`) полностью совместимы
  с OpenAI-схемой ответа — переиспользовать тот же `fetch`-стиль, что у LLM.

**Код:**
- `challenge/src/core/rag/{types,loader,chunker,embedder,store,pipeline,index}.ts`
- `challenge/src/demos/day-21.ts`
- `challenge/src/data/rag-sample/*.md` — smoke-корпус.

---

## День 22 — Первый RAG-запрос
**Дата:** 2026-07-01

**Задание (полный текст):**
> Реализуйте функцию: вопрос → поиск релевантных чанков → объединение с вопросом →
> запрос к LLM. Сравните ответ без RAG vs с RAG.
> Усиление: мини-набор из 10 контрольных вопросов с ожиданием и ожидаемыми
> источниками.

**Сделано:**
- `core/rag/llm.ts` — `makeLocalLlmClient`: СТРОГО локальный LLM из `.env`
  (`LOCAL_LLM_*`), при отсутствии бросает ошибку (внешние провайдеры НЕ используются).
- `retriever.ts` — вопрос → эмбеддинг → top-K чанков из индекса.
- `rag.ts` — `answerWithRag` (контекст + `[n]`-цитирование) и `answerNoRag`
  (общие знания).
- `eval.ts` + `src/data/rag-eval.json` — 10 контрольных вопросов с ожиданием и
  ожидаемыми источниками.
- Демо `day-22.ts`: прогон 10 вопросов в двух режимах, печать side-by-side +
  найденные источники с косинус-оценкой.
- CLI: `rag query "<q>" [--no-rag] [--strategy ...] [--k N]`, `rag eval`.

**Выводы:**
- RAG сильнее на фактах по своей базе (версии, команды, имена), без RAG модель
  галлюцинирует specifics. Косинус-оценка источников позволяет отделить точные
  попадания от шума (порог ~0.3–0.5 зависит от модели эмбеддингов).
- System-промпт «если в контексте нет — так и скажи» критичен: без него модель
  подмешивает общие знания в RAG-ответ.
- Два режима в одном агенте (`--no-rag`) наглядно показывают ценность индекса.

**Код:**
- `challenge/src/core/rag/{llm,retriever,rag,eval,index}.ts`
- `challenge/src/demos/day-22.ts`
- `challenge/src/data/rag-eval.json` — 10 контрольных вопросов.

---

## Feature: Telegram-бот «Фактчемпик» — память и шаржист чата (M1)
**Дата:** 2026-09-24
**Ветка:** `feat/factchempik-bot`
**Спека:** `prompts/factchempik-bot.md` (решения консилиума: `swarm-report/factchempik-plan-01.md`)

**Задание:** бот внутри приватного чата «Факты в чате» (-1001736860345, 949 747
сообщений), который по командам участников достаёт реальные цитаты конкретного
человека и (в следующих мильстоунах) воображает его реакции. M1 — бот без LLM:
FTS5-индекс, /цитата, /сказал, /игра, дизамбигуация имён, админ-команды.

**Железная продуктовая граница:** реальные цитаты — только из БД, атрибуция по
`from_id` проверяется кодом (не LLM), дата сообщения в выводе всегда; всё
воображаемое — только через 🎭-маркер первой строкой, проверяемый кодом.

**Что сделано:**
- `core/tg/botStore.ts` — аддитивные таблицы в `tg.sqlite` (`tg_bot_state` —
  offset getUpdates и рубильник /off; `tg_bot_aliases` — словарь имён с seed:
  савелий→Saveliy, севенс/sevens→Sevens ABSOLute, краснобелый→krasnobeliy2),
  случайные цитаты без `ORDER BY random()` (COUNT+OFFSET; для /игра — пробы
  случайных msg_id), каталог авторов одним GROUP BY (2.3 с → кэш 15 мин).
- `core/tg/ftsStore.ts` — FTS5-индекс в ОТДЕЛЬНОМ файле `tg-fts.sqlite`
  (~178 МБ на 865 948 документов): тексты только целевого чата, инкремент по
  курсору msg_id, полная пересборка в свежий `.build`-файл с подменой.
- `core/tg/botApi.ts` — тонкий клиент Bot API поверх `netFetch` (chokepoint):
  getMe/deleteWebhook/getUpdates/sendMessage/answerCallbackQuery.
  Токен в URL не логируется; 429 → retry_after; 409 → внятный exit.
- `core/tg/bot.ts` — цикл long polling (offset персистится после каждого
  апдейта, in-memory dedup update_id), allow-list (fail-closed), кулдаун
  3 команды/мин с подсказкой раз в 30 с, исходящая очередь ≥1.2 с с пагинацией
  4096→3900, SIGINT: drain → persist offset → exit 0; сетевые сбои → backoff ×2.
- Known limitation: автодополнения команд в UI Telegram отсутствуют — меню
  команд Bot API принимает только `[a-z0-9_]{1,32}`, команды M1 кириллические
  по спеку (setMyCommands падал BOT_COMMAND_INVALID на каждом старте — вызов
  убран; парсер читает текст сообщения, команды работают при ручном вводе).
- Команды M1: `/цитата` (топ-цитата чата/автора, дата всегда), `/сказал <имя>
  [тема]` (FTS5 `корень*` OR-набор + фильтр from_id, буст реакции+свежесть,
  3–5 цитат; тема из reply-сообщения, если не задана), `/игра` (цитата с
  реакциями ≥5, 40–400 зн., 4 кнопки, 90 с, счёт сессии, один раунд на чат),
  админ: `/reindex`, `/алиас`, `/off`/`/on`, `/стат`.
- Дизамбигуация имён: нормализация (lower, ё→е), алиас → точный, числовой
  from_id, подстрока по DISTINCT (from_name, from_id); 0 → отказ с 3
  подсказками; 1 → молча; >1 → inline-кнопки «имя · N сообщ. · годы» (60 с).
- 🎭-гейт M3 уже в коде и покрыт тестами: `core/tg/jokerMarker.ts` — порт
  `joker-marker.ts`/`joke-guard.ts` (1 ретрай, fallback с валидным маркером).
- Env: `getTgBotRuntimeConfig()` в `core/env.ts` + `.env.example`
  (`TG_BOT_ALLOW_CHATS` — fail-closed; `TG_BOT_OWNER_ID`; `TG_BOT_POLL_TIMEOUT`).
- CLI: `tg-bot` (+ `--index-only`, `--rebuild`), help и списки обновлены.
- Тесты: `pnpm --filter challenge test` — node --test + tsx, 43 юнит-теста на
  временных sqlite-фикстурах: резолвер, парсер, FTS-запрос (префиксы,
  стоп-слова), 🎭-гейт (валид/невалид/ретрай/fallback), очередь (гэп, 429,
  дроп), пагинация, кулдауны, формат цитаты (дата = инвариант).

**Замеры (реальный прогон 2026-09-24):**
- Полная сборка FTS: 865 948 документов. Наивный путь (WAL + коммит каждые
  5k + DELETE FROM поверх живого файла) — 85 с. Разобрано по частям: чистая
  вставка 866k — 8–10 с, чтение — 2.5 с, главный тормоз — WAL-чекпойнты
  (39 с) и пересборка поверх живого файла (71 с). Итог: пересборка в
  disposable `.build`-файл (journal=MEMORY) с атомарной подменой — **10.5 с**,
  файл 177.8 МБ, курсор msg_id=970710. Инкрементальный догон без новых
  сообщений — 0.0 с.
- Каталог авторов (GROUP BY по 950k строк) — 2.3 с → кэшируется.
- `pnpm --filter challenge typecheck` — чисто; тесты 43/43 зелёные;
  `list`-регресс — список демо не изменился; getMe smoke — отвечает.

**Решения/отклонения от спека:**
- seed «вячеслав→1321375335» из спека НЕ сажается: подстрока «вячеслав» матчит
  9 разных from_id — это кейс дизамбиг-кнопок, а не словаря (проверено lookup).
- owner = `TG_BOT_OWNER_ID`; без неё — первый ЛИЧНЫЙ (положительный) chat_id из
  allow-list. Буквальное «первый chat_id» было бы группой — админ-команды
  достались бы всей группе.
- `/сказал` шлёт полный текст цитаты (усечение 500) вместо `snippet()` —
  даты и так обязательны в каждой строке.
- Ответы бота — plain text без parse_mode: tainted-тексты БД не требуют
  HTML-экранирования, класс ошибок parse-режима исчезает.
- FTS-схема — супerset спека: добавлены UNINDEXED chat_id/topic_id
  (соответствует plan D3).

**Код:**
- `challenge/src/core/tg/{bot,botApi,botStore,ftsStore,botNames,botFtsQuery,
  botCommands,botQueue,jokerMarker}.ts` + тесты `*.test.ts`
- `challenge/src/core/env.ts`, `challenge/src/cli.ts`, `.env.example`


---

## Feature: «Изобрази автора» (/изобрази) — вторая игра бота «Фактчемпик»
**Дата:** 2026-09-24
**Ветка:** `feat/factchempik-bot`
**План:** `swarm-report/izobrazi-plan-01.md` (research: izobrazi-research-{architect,stack,product}-01.md)

**Задание (решение владельца):** вторая игра для бота — «Изобрази автора».
Бот выбирает настоящую цитату автора, чат 3 минуты сдаёт пародии его манеры
реплаями на анонс (каждая принятая запись тут же удаляется ботом — аноним),
затем голосование 90 с: 3 пародии + настоящая цитата вперемешку, у каждого
варианта правдоподобная дата (у настоящей — истинная). Ревил раскрывает,
где настоящая и кто автор какой пародии. Существующая /игра («кто это
сказал») остаётся без изменений; счёт сессии у игр общий.

**Правила и механика:**
- `/изобрази <имя> [тема]` — имя резолвится существующим резолвером (алиасы,
  дизамбиг-кнопки 60 с). Тема задана → настоящая цитата берётся по теме
  (FTS-путь /сказал); без темы — из игрового пула автора (40–400 зн.,
  реакции ≥5→3, без ссылок — новый `randomAuthorGameQuote`).
- Набор 3:00, в дело идут первые 3 записи (минимум 2), одна на человека,
  свою можно перезаписать. Раннее закрытие при 3/3, но не раньше 45 с
  (MIN_WINDOW; до этого анонс показывает «Принято: 3/3 — стартую…»).
- Отказы (запись не удаляется и не считается): >300 знаков; копипаст
  настоящей (нормализация + подстрока + ≥80% токенов — гард O(1), настоящая
  зафиксирована на старте раунда); дубль уже принятого текста.
- Принятая запись удаляется немедленно → анонимность до ревила. Не смог
  скрыть (бот не админ) → раунд отменяется с честным сообщением про права
  администратора. Фолбэка «в личку» нет.
- Голосование кнопками 1–4 (`vote:<token8>:<idx>`): голос за свой вариант
  отклоняется (мэпинг вариант→автор знает только бот), переголос — последнее
  действие, после дедлайна — «Голосование закрыто» без вскрытия; текст ack
  не зависит от правильности.
- Очки (общая доска с /игра, in-memory): угадал настоящую +1; пародист +1 за
  каждый чужой голос «его вариант = настоящая»; «Золотой шарж» +1 самой
  популярной пародии (ничья — всем делившим первое место).
- Один активный раунд на чат на ОБЕ игры; `/off` гасит активный раунд любой
  игры («Раунд прерван владельцем»); рестарт убивает раунд молча
  (known-limitation).

**Что сделано:**
- `core/tg/botImprov.ts` (новый) — вся логика игры: двухфазная state-machine
  collect→vote→ревил, приём/валидация записей, перемешивание вариантов,
  пост одним куском ≤3900, голоса last-wins, подсчёт очков; сеть — через
  инжектные deps (send/del/edit/answer), тайминги и кулдаун — опции
  конструктора (юнит-тесты без сети).
- `core/tg/bot.ts` — 5 точек интеграции: reply-ветка до парсера команд
  (реплай на анонс — всегда запись, жёсткий матч message_id), dispatch-кейс
  `/изобрази` + FTS-путь темы, роутинг callback `vote:`, чистка improv-таймеров
  в cancelTimers и /off, взаимоисключение через общий хелпер активного
  раунда; дизамбиг-интент `'изобрази'` доживает до кнопок.
- `core/tg/botApi.ts` — аддитивно `deleteMessage` (false на 400/403 = бот не
  админ) и `editMessageText` (счётчик на анонсе, best effort).
- `core/tg/botQueue.ts` — очередь возвращает message_id последнего куска
  (дроп → null; cancel-путь анонса).
- `core/tg/botStore.ts` — аддитивно `randomAuthorGameQuote` и
  `sampleAuthorDate` (реальный сэмпл date_iso автора — правдоподобные даты
  карточек пародий).
- Фикс попутного бага: `/игра` вскрывалась после `/off` (revealRound не
  проверял рубильник) — гейт добавлен, ревил выключенного бота невозможен
  ни по одному пути; покрыт тестом.
- Тесты: 94 (было 45) — state-machine, гарды записи до deleteMessage,
  self-vote/переголос/поздний голос, очки/шарж/ничья, cancel-пути (/off,
  delete-fail, дроп анонса), 0/1 записей, фикс D7, даты вариантов,
  общий счёт с /игра.

**Known limitations:**
- Для /изобрази бот должен быть админом чата с правом удаления сообщений —
  иначе раунды отменяются с честным сообщением.
- Рестарт/SIGINT убивает активный раунд молча; старые кнопки отвечают
  «Раунд уже завершён»; очки сессионные (in-memory, общие для двух игр).
- Рубильник /off глобален: в своём чате он гасит активный раунд с постом
  «Раунд прерван владельцем», в остальных чатах allow-list незакрытые раунды
  замораживаются молча (ревил выключенного бота не публикуется — фикс
  вскрытия после /off).
- Кулдаун 3 команды/мин не действует на записи-реплаи — лимит механикой:
  1 запись на человека, 3 слота, окно 3:00.
- Даты пародий — сэмплы реальной активности автора (декоративные); на посте
  вариантов всегда есть рамка «одно из N — настоящая цитата». Содержание
  пародий бот не модерирует — модерация владельцем + /off.

**Код:**
- `challenge/src/core/tg/botImprov.ts` (новый) + `botImprov.test.ts`,
  `bot.test.ts`; изменены `bot.ts`, `botApi.ts`, `botQueue.ts`, `botStore.ts`,
  `botCommands.ts` и их тесты.

---

## Бот «Максим Артемьевич» — QA Lead front-back (напутствия + капс)
**Дата:** 2026-10-07

**Задание (решение владельца):** новый бот в рамках челленджа — «Максим
Артемьевич», QA Lead команды front-back. Иногда присылает в чат напутственные
сообщения («с продом повнимательнее», «переводи в ревью»), генерируемые
DeepSeek; если за 2 минуты нет ответа — капсит и пингует участников.
Настройка температуры сообщений, чтобы фразы менялись.

**Что сделано:**
- `core/tg/maximBot.ts` (новый) — самодостаточный бот на `BotApiClient`:
  long polling (тот же chokepoint netFetch), backoff ×2 до 30 с, выход по
  409 Conflict, graceful shutdown с persist состояния.
- Расписание: одно напутствие в день релиза (релизный календарь — эпоха +
  период, по умолч. 2026-10-06 + 14 дней: релизы 41, 43, …) в случайный
  момент окна 10:00–20:00 (локаль), всё переопределяется env.
  **Изменение 2026-10-09:** напутствия — только в день релиза, одно за день
  (раньше — hot-окно «день релиза + следующий» каждые 60–180 мин плюс одно
  напутствие раз в 3 дня в обычные дни); капс-эскалация и диалоги по
  обращению сохранены.
- Генерация фраз: `LlmClient` с конфигом `getMaximLlmConfig()` — ИМЕННО DeepSeek:
  напрямую 'deepseek-chat' (DEEPSEEK_API_KEY) или через OpenRouter
  ('deepseek/deepseek-chat-v3.1', override — MAXIM_MODEL); температура из
  состояния; фолбэк — заготовленные фразы при сбое LLM.
- Эскалация: любое человеческое сообщение в чате снимает pending; через
  `MAXIM_CAPS_DELAY_SEC` (по умолч. 120) молчания — КАПС-версия фразы реплаем
  + пинг до 3 последних активных участников (по username). Один капс на
  напутствие.
- Команды в чате (префиксные, в чате живут другие боты): `/start` — статичное
  приветствие (без LLM, ноль токенов DeepSeek), `/maxim_temp [0–2]` —
  показать/задать температуру на лету (persist), `/maxim_say` — напутствие
  сейчас (кулдаун 60 с), `/maxim_status` — статус.
- Интерактив: обращение к Максиму (реплай на его сообщение, @упоминание или
  «максим, …» в начале) → диалоговый ответ реплаем от персоны «очень бережный
  и заботливый руководитель, который временами выходит из себя». Настроение
  бросается кубиком: 15% — вспышка (старт КАПСОМ, к концу возврат к заботе),
  иначе спокойная забота. Контекст — последние 6 пар реплик (in-memory, своя
  история на каждый чат), цитата реплая подмешивается в промпт.
- Личка с ботом: любое сообщение в DM = обращение (упоминание не нужно),
  отвечает той же персоной; команды `/maxim_temp`, `/maxim_say`, `/maxim_status`
  работают и из лички (напутствие всегда уходит в рабочий чат, в DM —
  подтверждение). Privacy mode на личку не влияет. Активность в личке
  эскалацию в чате НЕ снимает.
- Состояние — JSON `.data/maxim-bot.json` (offset, температура, pending,
  участники, nextNudgeAt), атомарная запись tmp+rename; протухший pending
  (>10 мин) при рестарте сбрасывается без капса.
- Конфиг — `getMaximBotConfig()` в `core/env.ts` (инвариант: process.env
  только в env.ts); fail-closed без `MAXIM_BOT_TOKEN`/`MAXIM_CHAT_ID`.
- CLI: `pnpm --filter challenge start -- maxim-bot`.
- Деплой: systemd `factbot-maxim.service` (EnvironmentFile общий `.env`,
  прокси через gost/туннель), чат `-4805270771`, бот @alert_max_temi4_bot.
- Тесты: 7 новых (календарь hot-дней, расписание, капс-текст, пинги,
  парсер команд, валидация температуры) — всего 122, зелёные.

**Known limitations:**
- Бот должен видеть сообщения чата: privacy mode у BotFather выключен
  (или бот — админ), иначе pending никогда не снимается и он капсит всегда,
  а диалоговый интерактив не работает совсем.
- Диалоговый контекст — in-memory (6 пар реплик): рестарт = чистый лист.
- Пингуются только участники с username (text_mention не реализован) и только
  те, кого бот видел с момента запуска (участники накапливаются в состоянии).
- «Ответом» считается любое человеческое сообщение в чате, не только реплай.

**Код:** `challenge/src/core/tg/maximBot.ts` + `maximBot.test.ts`;
изменены `core/env.ts`, `cli.ts`, `.env.example`.

---
## ADVANCED Day 1 — Rules: `AGENTS.md` v2 + `.omp` (глобальный конфиг, субагенты, скиллы)
**Дата:** 2026-10-19

**Задание:** проанализировать проект и создать файл правил; описать стек,
архитектуру, структуру папок, naming conventions и паттерны; использовать
глобальный конфиг, локальный конфиг, субагентов и скиллы; включить 3–5 хороших
примеров, 3–5 антипаттернов и шаблон типичного файла; проверить на боевой задаче
одним промптом; усилить правила по результатам и повторить генерацию.

**Что сделано:**
- `AGENTS.md` переписан в v2 под текущую реальность: `challenge/` + `web/`,
  scoped override Next.js, направление зависимостей, `server-only`/chokepoint,
  `withDb`, zod-границы, `safeMessage`, naming, шаблоны core-сервиса и Route
  Handler, тесты, Definition of Done, git-дисциплина.
- Добавлен sticky `.omp/RULES.md` — короткие жёсткие инварианты (no `any`,
  no `console.log` в переиспользуемом коде, SQL только `?`, surgical diff,
  no new deps/day-NN, no commit/push без запроса).
- Добавлены project-субагенты `.omp/agents/project-implementer.md` и
  `project-reviewer.md`.
- Добавлены скиллы `.omp/skills/add-core-service`, `add-web-endpoint`,
  `project-validation`.
- Создан глобальный `~/.omp/agent/AGENTS.md` (общие правила, проект побеждает).
- Боевая задача: core `TokenEstimator` + `POST /api/tokens/estimate` + тесты
  (`node:test` и Vitest). Один промпт, две генерации: v1 и v2.
- Артефакты эксперимента: `docs/advanced-day-01/` — промпт, правила v1/v2,
  диффы обеих генераций, оценки, сравнение и факторы качества.

**Результат эксперимента:**
- Gen1 (v1): typecheck PASS, core 101/101, route 10/10; отклонения — static-only
  класс, мутабельные контракты, нет доменной валидации бюджета, несвязанная
  правка комментария, нет CHANGELOG.
- Gen2 (v2): typecheck PASS, core 105/105, route 10/10, web suite 235/235
  (`--maxWorkers=2`); `readonly`, instance-сервис с options, `RangeError`,
  `{ ok: true }`, `safeMessage`, CHANGELOG, без несвязанных правок.
- Время генерации: ~12 мин → ~2 мин 42 с.
- Smoke: `next start` на loopback → 401 без cookie, 200 после login
  (`{ok:true,total:2,messages:[...],budget:10,remaining:8,fits:true}`).

**Выводы:**
- Сильнее всего качество улучшили шаблоны файлов, sticky-запреты и скилл
  `add-web-endpoint`; они превратили «лучшую практику» в проверяемую форму.
- Правила не заменяют чтение существующего кода: Gen1 был хорош именно потому,
  что ассистент открыл `forms.ts`, `challenge.ts` и route-тесты.
- Полный suite обязателен: он выявил, что импорт всего chokepoint-барреля в
  route-тесте замедляет воркеры. Integration-fix мокает баррель до одного
  экспорта; правило v2 дополнено явным разрешением boundary-мока.
- На этом Windows-хосте `vitest run` без ограничения воркеров нестабилен
  (timeout старта UI-воркеров); рабочий fallback — `--maxWorkers=2`.
  `next build` проходит compile/typecheck/40 страниц, но падает на EPERM
  symlink при standalone trace copy — ограничение окружения.

**Код/артефакты:**
- `AGENTS.md`, `.omp/RULES.md`, `.omp/agents/*`, `.omp/skills/*`,
  `~/.omp/agent/AGENTS.md`
- `challenge/src/core/tokenEstimator.ts` + `.test.ts`, `core/index.ts`
- `web/app/api/tokens/estimate/route.ts`, `web/lib/shared/forms.ts`,
  `web/lib/server/challenge.ts`, `web/test/unit/tokens-estimate-route.spec.ts`
- `docs/advanced-day-01/**`

---

## Feature: оценка токенов — core `TokenEstimator` + `POST /api/tokens/estimate`
**Дата:** 2026-10-19

**Что сделано:**
- `challenge/src/core/tokenEstimator.ts` (новый) — `TokenEstimator`: эвристика
  `Math.ceil(UTF-8 bytes / 4)` без токенизатора и новых зависимостей.
  `estimateText` возвращает `{bytes, tokens}` одной строки;
  `estimate(messages, budget?)` — `total`, per-message breakdown
  (`index/role/bytes/tokens`), `budget`, `remaining`, `fits`.
  Инварианты: `bytesPerToken > 0`, `budget` — целое ≥ 0 (`RangeError`).
  `total` — сумма по-сообщенных оценок, поэтому всегда сходится с breakdown;
  без `budget` → `budget/remaining = null`, `fits = true`.
- `challenge/src/core/index.ts` — публичный экспорт сервиса, константы и типов.
- `web/lib/server/challenge.ts` — экспорт через единственный chokepoint.
- `web/lib/shared/forms.ts` — `tokenEstimateSchema`: `role` enum,
  `content` ≤ 100000 символов, `messages` ≤ 200, `budget` целое ≥ 0;
  content не trim'ится (оценка реального промпта).
- `web/app/api/tokens/estimate/route.ts` (новый) — POST:
  zod-валидация → core → JSON `{ok, total, messages, budget, remaining, fits}`,
  `Cache-Control: no-store`; 400 на zod/RangeError. Роут закрыт admin-middleware
  (в `PUBLIC_PATHS` намеренно не добавлен).
- Тесты: core 11 (`node:test`), web 10 (Vitest) — UTF-8 multibyte, пустые
  входы, границы 200 сообщений/100000 символов, нулевой/недостаточный бюджет,
  `fits`, не-JSON тело.

**Риски/ограничения:**
- Эвристика bytes/4 не токенизатор модели: на кириллице/эмодзи оценка
  приблизительная, для бюджета контекста нужен запас.
- Новых пакетов нет; сервис чистый (без сети/БД/`process.env`).

---

## Feature: Blogs Foundation — мульти-блог и in-app guide
**Дата:** 2026-09-30 (feature), 2026-10-22 (guide)

**Что сделано:**
- Мульти-блог-основа: три seeded-блога («Иди на факты глянь», «Артемия Артель»,
  «Невский храм на Доваторцев») + `blog_id` в новостях/постах/образцах стиля.
- `GET /api/blogs` — список блогов с производными флагами (`hasProfile`,
  `sourcesCount`, `tgChatIdSet`).
- `PATCH /api/blogs/[slug]` — настройка блога: имя, профиль голоса, TG-чат,
  RSS-источники (пустой массив → дефолтные фиды).
- Блог учитывается в `/blog/news`, `/blog/digest`, `/blog/posts` (фильтр),
  `/blog/style` и блог-pipeline: выбирает RSS-источники, профиль голоса и
  штампует `blog_id`.
- Guide на `/blog/posts`: короткий блок «как пользоваться · 4 шага» — выбрать
  блог, создать черновик, проверить/отредактировать, опубликовать в Telegram;
  сноска про `PATCH /api/blogs/<slug>` и профиль голоса в `/chat`.

**Как пользоваться (кратко):**
1. Выбрать блог на `/blog/news` / `/blog/pipeline` / `/blog/digest` или
   фильтром на `/blog/posts`.
2. Создать черновик через pipeline/news.
3. Открыть пост, проверить и отредактировать.
4. Опубликовать в Telegram из карточки поста.
5. Новый блог: задать RSS и профиль голоса через `PATCH /api/blogs/<slug>`;
   профиль создаётся в `/chat` (`/profile`). Без профиля и источников
   генерация недоступна.

**Тесты:**
- `web/test/unit/blog-multiblog.spec.ts` — мульти-блог-контракты.
- Ручной smoke: `/blog/posts` 200, блок guide присутствует.

**Код:**
- `challenge/src/core/db.ts`, `core/agents/*`, `web/lib/server/blogs.ts`,
  `web/app/api/blogs/**`, `web/app/api/blog/**`, `web/app/blog/**`,
  `web/app/dashboard/page.tsx`, `web/lib/shared/forms.ts`,
  `web/lib/server/challenge.ts`, `web/scripts/auto-drafts.ts`.

---

## ADVANCED Day 2 — Profiles: 4 профиля агентного режима в `AGENTS.md`
**Дата:** 2026-10-23

**Задание:** профили Bug Fix + Research (промпт, ДОЛЖЕН/НЕ ДОЛЖЕН, формат
ответа), проверка на реальной задаче с первого запуска; усиление — третий
профиль под частую задачу.

**Что сделано:**
- Профили переехали из исторического `CLAUDE.md` в канонический `AGENTS.md`
  **§13 «Профили агентного режима»** — в переводе на живые скиллы
  `.omp/skills/` и агентов omp (`scout`/`task`/персоны); `CLAUDE.md`
  670 → 286 строк, дублей нет. Git-дисциплина перенумерована в §14.
- Четыре профиля: **Бизнес-фича**, **Поиск бага** (перенос STRICT-графов
  стадий, лимитов, шаблонов Report), **Research** и **Граф проекта** (новые;
  третий профиль — по выбору владельца: граф проекта/компонентов/фич).
- Боевые прогоны новых профилей (обa — с первого раза):
  - Research: «как устроена авторизация в web» → 26 файлов с file:line,
    25 связей, 10 выводов, 6 открытых вопросов, честное «не проверено»;
  - Граф проекта: 121 узел / 402 ребра / 0 висячих; god-модули (types 23,
    env 16), цикл `core/index ↔ agents/*`, 2 нарушения границ (chokepoint,
    process.env вне env.ts), замороженные demos в живых цепях.
- Доработка по итогам прогона: в §13.6 добавлен слой web-server.
- Стадийные профили ранее реально использовались (swarm-report: 8 фичевых
  сценариев, 3 баговых — web-joker-stream, web-qwen35-label, web-prod-blank-csp).

**Код/артефакты:**
- `AGENTS.md` §13–14, `CLAUDE.md` (указатель)
- `docs/advanced-day-02/{README,research-run-01,graph-run-01}.md`

---

## ADVANCED Days 3–5 — Testing / Local Boost / Execution Loop
**Дата:** 2026-10-23

**День 3 (Testing):** два уровня. Ур.1 — тесты на 3 непокрытых модуля
(`core/rag/quotes.ts` +6, `core/rag/chunker.ts` +9, `web shared/it-facts` +3);
challenge 153/153, web 238/238. Ур.2 — 5 smoke-сценариев через браузер-MCP
(логин, гостевой гейт, CRUD задачи, блог+фильтр, логаут) со скриншотами на
каждом шаге (`docs/advanced-day-03/shots/`); находки: двойная cookie-ловушка
127.0.0.1 vs localhost, дев-овлея Next поверх футера, неочевидный /mcp/todos.
Усиление: flow «после PR = typecheck x2 + suite x2 + smoke = единый отчёт» +
отрепетирован сценарий «задеплоил фичу → обнови smoke» (S6, guide-блок).

**День 4 (Local Boost):** Ollama + Continue.dev. Модели под железо (12 ядер,
16GB): `qwen2.5-coder:7b` чат (41.8 tok/s короткая генерация) +
`qwen2.5-coder:1.5b-base` FIM-автокомплит (76.8 tok/s). Правила AGENTS.md —
выжимкой в системный промпт; контекст и параметры в
`docs/advanced-day-04/continue-config.yaml` (num_ctx явный). Те же задачи,
что облачный: фича (промпт Дня 1) — код непригоден (8 нарушений правил);
Research — форма без глубины; точечный SQL-фикс — корректен за 10.5 с.
Таблица и рекомендация «где хватает локальной» — в отчёте.

**День 5 (Execution Loop):** 23 issue в GitHub (#15–#37; 21 в пуле + 2 по
находкам smoke Дня 3), labels day-3/4/5 × bug/test/feature/docs/chore. Два
прогона без паузы: 6 задач (Дни 3–4) за 37.4 мин, 17 задач пула за 25.6 мин —
факт по git/GitHub timestamps (методика в отчёте); «с первого раза» 83% → 93%
— самоотчёт, артефактов итераций нет. Финальная валидация challenge 167/167,
web 254/254. Итоги пула:
разорван цикл core/index↔agents; 3 роута возвращены за chokepoint; TG-env
читается только через accessors env.ts; requireAuth добавлен на
/api/rag/index; /api/health (публичный) + rewrite /todos; 27 новых тестов;
доки (AUTHORIZATION, профили в README, шаблон профиля §13.8); #28 закрыт как
неактуальный, #37 — не-баг (дев-овлея Next).

**Процесс (после Дня 5):** находки вне скоупа не чинятся «заодно» — заводятся
issues по `.github/ISSUE_TEMPLATE/bug.md` с приоритетом `P0`–`P3`; текущая
задача продолжается, кроме `P0`/`incident` (`AGENTS.md` §13.9). Лимиты: WIP=1
`in-progress`, repro ≤3, Fix↔Validation ≤2, открытых `P0`/`incident` — 0,
`P1` — ≤5. Метки GitHub: `P0`–`P3`, `incident`, `hotfix`, `in-progress`,
`needs-triage`, `blocked`. Метрики: `node scripts/loop-metrics.mjs --from N
--to M` (GitHub API; старт из `in-progress`, fallback — закрытие предыдущей).
Причина: время в отчёте Дня 5 было самоотчётом (заявлялось ~160 мин, фактически
25.6). Loop включается только явно (`loop-run` / «execution loop» / «пул
задач») и инструментируется milestone + `loop-run`; провал первой попытки —
`iteration:2` + `cause:*`, остановка с вопросом — `asked-user`. Без этих меток
`loop-metrics.mjs` печатает `n/a` для first-try/остановок/причин, а не 0 и не
оценку. Правило harness-нейтральное: источник истины — `AGENTS.md`,
`.omp/RULES.md` дублирует инварианты, шаблоны и метки живут в GitHub.

**Риски/ограничения:** перебор локальных моделей ограничен 16GB RAM;
vitest на этом хосте — только с --maxWorkers=2 (AGENTS §10); 3 итерации в
пуле — тест-авторинг, продуктового кода не касались.

**Код/артефакты:**
- `docs/advanced-day-03/**` (отчёт + скриншоты), `docs/advanced-day-04/**`
  (конфиг, rules, сырые прогоны, таблица), `docs/advanced-day-05/README.md`
- `challenge/src/core/{env.ts,agents/telegram*.ts,agents/*(imports)}`,
  `challenge/src/core/{sanitize,strategy,quotes,chunker}.test.ts`
- `web/app/api/rag/index/route.ts`, `web/app/api/health/route.ts`,
  `web/middleware.ts`, `web/next.config.ts`
- `web/test/unit/{it-facts,rag-index-route,health-route,session,forms}.spec.ts`
- GitHub Issues #15–#37 (все закрыты)

---

## ADVANCED Day 5 (продолжение) — Product loop: геймификация, ИИ-помощник, автоматизация, интеграции, Android

**Дата:** 2026-10-23. Исполнитель: агент (execution loop, профиль Бизнес-фича §13.3).
Пул: issues #38–#50, milestone `run-2026-10-23-product`.

**Задание (полный текст):**
> Реализовать фичи: геймификация, ИИ-помощник, полная автоматизация указанных
> блогов через сайт и TG-бота (для «Факты глянь» — стандартный промпт Антонова),
> интеграции с Телеграмом, календарями, проекты/папки. Также: смена темы,
> интеграция с Google Calendar, интеграция с другими сервисами, уведомления,
> поддержка. Затем нативное Android-приложение с небанальным дизайном,
> поддерживающее функциональность web. Рефакторинг без потери работоспособности.

**Сделано (core, `challenge/src/core/`):**
- `workspaceDb.ts` — проекты → папки → элементы (заметки/задачи/ссылки), каскадное
  удаление, `listUpcoming` для календаря.
- `gamification.ts` — XP/уровни (100·n²), ежедневные серии, 8 достижений, журнал.
- `notifications.ts` — центр уведомлений + DI-фан-аут по каналам.
- `automation.ts` — правила-расписания per blog, история запусков, `runDue`/`runNow`.
- `calendar.ts` + `googleCalendar.ts` — ICS (RFC 5545) и клиент Google Calendar
  (OAuth refresh, без внешних зависимостей).
- `webhooks.ts` — исходящие webhook-подписки, HMAC-SHA256, доставка с таймаутом.
- `supportCenter.ts` — FAQ-поиск по токенам + тикеты (FAQ про сам продукт).
- `assistant.ts` — снапшот состояния → системный промпт ассистента.
- `env.ts` — accessors `getGoogleCalendarConfig` / `getMobileApiToken`.

**Сделано (web, `web/`):**
- API: `/api/workspace/*`, `/api/gamification`, `/api/notifications`,
  `/api/automation`, `/api/calendar` + `feed.ics` + `sync`, `/api/integrations/webhooks`,
  `/api/support/{faq,tickets}`, `/api/assistant`, `/api/mobile/bootstrap`.
- UI: `/projects`, `/gamification`, `/notifications`, `/automation`, `/calendar`,
  `/support`, `/assistant`, `/integrations` + группа навигации `product`,
  колокольчик в Nav.
- Тема: 4 палитры (dark/light/sepia/neon) + system, выбор в /settings.
- Мобильный доступ: `Authorization: Bearer MOBILE_API_TOKEN` для `/api/*`.
- Автоматизация: `web/lib/server/automation-service.ts` — конвейер поста + стиль
  Антонова для блога «Иди на факты глянь» + автопубликация в TG.

**Android:** `android/` — Kotlin + Jetpack Compose, тёмная тема с акцентом
(#8B7CFF) и лаймом, экраны подключения/дашборда/проектов/автоматизации/
календаря/уведомлений/ассистента/поддержки/настроек, сетевой слой к реальным API.

**Рефакторинг:** `web/lib/server/db.ts` — единый реестр singleton; `http.ts` —
общие JSON-хелперы (error/ok envelope + no-store).

**Проверки:** challenge typecheck + 196 тестов; web typecheck + 262 теста;
web build — 48 страниц генерируются, падает только на standalone-symlink
(EPERM на Windows — известное окружение, не код).

**Риски/ограничения:** Google Calendar требует OAuth-креды; без них — .ics-экспорт.
Автоматизация выполняется, пока запущен сервер (расписание без внешнего cron).
TG-бот «Медиум» (чат-память) не изменён — автоматизация управляется с web.

**Код:** `challenge/src/core/{workspaceDb,gamification,notifications,automation,calendar,googleCalendar,webhooks,supportCenter,assistant}.ts`,
`web/app/api/{workspace,gamification,notifications,automation,calendar,integrations,support,assistant,mobile}/**`,
`web/app/{projects,gamification,notifications,automation,calendar,support,assistant,integrations}/page.tsx`,
`android/**`. GitHub Issues #38–#50.

---

## Fix #51 — `pnpm --filter web build` на Windows: standalone только вне win32
**Дата:** 2026-10-24. Профиль «Поиск бага» (AGENTS §13), issue #51 (bug P3).

**Симптом:** на Windows `next build` проходил compile, manifest'ы и prerender
всех страниц, но падал на этапе 'Collecting build traces' с `EPERM` при
создании symlink react → `.next/standalone/node_modules/react`: без Developer
Mode создание symlink на Windows запрещено. Это ограничение окружения, не кода
(отмечалось ещё в ADVANCED Day 1 и Дне 5); падала только трассировка
standalone-артефакта.

**Решение:** standalone нужен только prod-деплою на Linux
(`docs/HERMES-DEPLOY-RUNBOOK.md`), поэтому в `web/next.config.ts` он включается
только при `process.platform !== 'win32'` либо явно: `NEXT_STANDALONE=1`
(форс-флаг для CI/Linux: включает standalone-вывод, но прав на symlink на
Windows не добавляет — без Developer Mode/админа сборка упадёт той же EPERM). Обычный build
достаточен для `next start`/дев-смоков — start standalone-артефакт не требует.
`postbuild` в `web/package.json` (копия `.next/static` в standalone) выполняется
только когда `.next/standalone` существует — иначе на Windows он падал бы
следом с ENOENT. Поведение Linux-деплоя не изменилось.

**Проверки:** на этой Windows-машине `pnpm --filter web build` — код 0
(48 страниц), `pnpm --filter web typecheck` и `pnpm --filter web test` — зелёные.

**Код:** `web/next.config.ts`, `web/package.json` (guard postbuild).

---

## Feature: пресет стиля блога (stylePreset) — стиль на этапе генерации
**Дата:** 2026-10-24. Issues #65, #83; хак удалён по #56.

**Что сделано:**
- `challenge/src/core/stylePreset.ts` (новый) — реестр пресетов:
  `StylePreset = 'default' | 'antonov'`; `ANTONOV_SYSTEM_PROMPT` — компактная
  выжимка «Антоновайзера», зашита константой (md в рантайме не читается);
  `resolveStylePreset` — всё, кроме точного `antonov` (включая null/мусор),
  резолвится в `default`; `stylePresetLabel`, `presetSystemPrompt`.
- Хранение: колонка `blogs.style_preset` (`TEXT NOT NULL DEFAULT 'default'`);
  seed — «Иди на факты глянь» = `antonov`, остальные `default`. Миграция
  легаси-БД идемпотентна: `hasColumn`-guard → `ALTER TABLE ... ADD COLUMN` +
  разовый backfill дефолт-блога; повторное открытие выбор пользователя не
  перетирает. Битое/неизвестное значение читается как `default`.
- Течение: `runNewsPipeline` → PostWriter — при активном пресете system-промпт =
  промпт пресета + блок «КАНАЛ И ПРОФИЛЬ», few-shot `style_samples`
  пропускаются; без `blogId` (легаси/REPL) — прежняя default-ветка.
- Web: `GET /api/blogs` отдаёт `stylePreset`; `PATCH /api/blogs/[slug]`
  принимает его (zod `z.enum(['default','antonov'])`); `/api/automation`
  прокидывает пресет в правила; селектор «пресет стиля» в карточке каждого
  правила на `/automation`.
- Удалён web-хак `applyAntonovStyle` (#56): второй LLM-проход, переписывавший
  готовый пост «Антоновайзером» для захардкоженного `lookatfacts` после того,
  как PostWriter уже писал тем же пресетом — двойная стилизация и двойная
  стоимость. Пресет стал единственным источником стиля; `STYLE_SYSTEM_PROMPT`
  остался для независимых потребителей (`/style/rewrite`, `/antonov/*`,
  `auto-drafts --style`).
- Description на `/automation` переписан под новый механизм (#65): «Стиль
  задаётся пресетом блога ниже; пресет Антонова — один из вариантов».

**Риски/ограничения:** пресет применяется только там, где `write()` вызывается
с `blogId` (автоматизация, CLI news); REPL-демо сознательно вне пресета.
Fallback-поведение изменилось: хак молча возвращал оригинал при сбое LLM,
теперь сбой генерации роняет run правила.

**Проверки:** challenge — `stylePreset.test.ts`, `db.test.ts`
(seed/update+reopen/легаси-миграция), `postWriter.test.ts` (antonov/default);
web — `automation-route.spec.ts` проверяет `stylePreset`; typecheck обоих
пакетов чистый; validation (code-reviewer + test-engineer) — PASS.

**Код:** `challenge/src/core/{stylePreset,db}.ts`,
`challenge/src/core/agents/postWriter.ts`,
`web/lib/server/automation-service.ts`, `web/app/automation/page.tsx`,
`web/app/api/{blogs,automation}/**`, `web/lib/shared/forms.ts`.

---

## Feature: входящие webhooks — публичный приём событий с HMAC
**Дата:** 2026-10-24. Issues #84, #62 (rate-limit), #64 (тесты bypass).

**Что сделано:**
- `challenge/src/core/inboundWebhooks.ts` (новый): таблица `inbound_hooks`,
  `generateInboundSecret`, `InboundHookDb` (create/list/get/delete — секрет
  возвращается только при create), `handleInboundEvent` с двумя целями:
  `notification` (центр уведомлений) и `todo`.
- Публичный приём: `POST /api/integrations/inbound/<id>` — HMAC-подпись в
  заголовке `x-artel-signature`, вычисляется по сырому телу ДО `JSON.parse`;
  404 (нет хука) / 401 (подпись) / 400 (тело/схема). Управление хуками — под
  session-auth: `GET /api/integrations/inbound` (список без секретов), `POST`
  (create, секрет показывается один раз), `DELETE /<id>`.
- Middleware-bypass строго `POST` + числовой id: другие методы и пути
  управления хуками идут через обычную авторизацию.
- Rate-limit на публичный POST (#62): in-memory fixed-window — 30 неудачных
  попыток (400/401/404) за 5 минут → `429` + `Retry-After`; успешная подпись
  сбрасывает окно; состояние в `globalThis` переживает HMR dev-сервера,
  сбрасывается рестартом.
- Хранение: `webhooks.sqlite` — тот же файл, что у исходящих `WebhookDb`
  (два коннекта, WAL).

**Риски/ограничения:** секрет хука хранится в SQLite открытым текстом —
осознанный компромисс (HMAC-верификация требует исходный секрет, хешировать
нельзя), задокументирован в `docs/AUTHORIZATION.md`; митигации — loopback-БД,
`.data/` вне git, секрет показывается один раз, ротация = DELETE + новый хук,
rate-limit.

**Проверки:** core `inboundWebhooks.test.ts`; web
`inbound-webhooks-route.spec.ts` — 13 тестов (подпись/ошибки + 3 rate-limit:
429, новое окно после паузы, сброс успехом); `middleware.spec.ts` —
bypass-ветки; на момент #62 web suite — 54 файла / 393 теста зелёные.

**Код:** `challenge/src/core/inboundWebhooks{,.test}.ts`,
`web/app/api/integrations/inbound/**`, `web/middleware.ts`,
`web/app/integrations/page.tsx`, `web/lib/shared/forms.ts`,
`docs/AUTHORIZATION.md`.

---

## Feature: браузерные уведомления — opt-in поверх колокольчика
**Дата:** 2026-10-24. Issue #85; тесты футера — #64.

**Что сделано:**
- `web/app/components/browserNotify.ts` (новый) — хук
  `useBrowserNotifications`: Notification API без Web Push — работает, только
  пока открыта вкладка. Поллинг `/api/notifications?unread=1` раз в 60 с при
  видимой вкладке; opt-in — тумблер в дропдауне колокольчика (`NotificationBell`)
  с честным текстом при `permission=denied` и без футера, если API нет; маркер
  последнего показанного id в `localStorage` (`browserNotify:enabled`, lastId);
  первый полл засевает маркер, чтобы не показать лавину старых; клик по
  уведомлению фокусит окно; тихая деградация.
- Контракт `/api/notifications` не менялся — `?unread=1` уже поддерживался.

**Проверки:** `browser-notify.spec.tsx` — 5 тестов хука (seed-полл, показ
новых, клик, denied, нет API); `notification-bell.spec.tsx` — 4 ветки opt-in
футера (#64); web suite зелёный.

**Код:** `web/app/components/{browserNotify.ts,NotificationBell.tsx}`,
`web/test/ui/{browser-notify,notification-bell}.spec.tsx`.

---

## Feature: TG-команды /уровень /блоги /авто + XP за игры
**Дата:** 2026-10-24. Issues #58, #86, #59.

**Что сделано:**
- Команды бота «Медиум»: `/уровень` — публичная (`🏆 Уровень N · X XP
  (до уровня N+1 — Y XP, прогресс P%). 🔥 Серия: S дн. (рекорд: B дн.)`; без
  gamification — «Геймификация недоступна»); `/блоги` и `/авто
  on|off|status|run` — owner-only (список блогов со статусом правил; вкл/выкл
  по slug или id; статус + последний запуск; запуск сейчас с автопубликацией
  при `auto_publish`). Ошибки запуска redact'ятся (`<url>`, `Bearer ***`,
  `sk-***`, кап 200 символов). `medium_level` добавлен в публичное меню
  бота; алиасы `level`/`муровень`.
- `challenge/src/core/tg/automationRun.ts` (новый) — core-раннер:
  `createTgAutomationRunner()` (BlogDb + LlmClient + BlogAutomation),
  `runBlogOnce()` — зеркало web-адаптера; профиль голоса загружается как в web —
  `/авто run` пишет тем же голосом, что web-автоматизация того же блога.
- XP за игры (#59): хук `awardGame` подключён в ревиле `/изобрази` —
  «золотой шарж» → `tg_game_win` (+15), угадавший настоящую →
  `tg_game_play` (+2), `ref = improv:<chatId>:<userId>`; сбой sqlite не срывает
  ревил. События и очки уже были в реестре — начисление теперь живое.

**Проверки:** `botAutomation.test.ts` — 8/8 (блоги, авто on/off/status/run,
redact, throw-пути); `bot.test.ts` — dispatch owner/не-owner + сквозной раунд
improv с реальным temp-sqlite (`tg_game_win` + `tg_game_play`, XP 17 за раунд);
`pnpm --filter challenge test` — 224/224; validation — PASS.

**Код:** `challenge/src/core/tg/{bot,botCommands,botAutomation,automationRun,botImprov}.ts`
+ тесты, `challenge/src/core/gamification.ts`.

---

## Fix #53 — планировщик автоматизации в web-процессе (instrumentation)
**Дата:** 2026-10-24. Issues #53, #77 (dev-фикс).

**Что сделано:**
- `web/lib/server/automation-scheduler.ts` (новый) — `AutomationScheduler`
  (server-only, DI botQueue-стиль): тик 60 с, reentrant-guard (пока in-flight
  `runDue` не завершился, тики пропускаются), `stop()` снимает таймер и
  дожидается in-flight через инжектируемую `sleep`; ошибка тика уходит в
  `onError` — цикл продолжается; повторный `start()` — no-op.
- `web/instrumentation.ts` (новый) — `register()`: no-op вне nodejs-runtime
  или без `AUTOMATION_ENABLED=1`; dynamic import server-only модулей
  (edge-сборка их не тянет); `SIGTERM`/`SIGINT` → graceful stop; ошибка старта
  логируется без падения процесса.
- Попутный фикс #77: в dev Next собирал edge-вариант instrumentation
  (middleware был edge) → 500 на всех страницах (`Module not found: 'path'`).
  `middleware.ts` — `runtime: 'nodejs'` внутри `config` (топ-левел export
  middleware игнорирует); `next.config.ts` — alias
  `instrumentation.ts → edge-register-stub.ts` (пустой `register()`) для
  edge-компилятора в dev.

**Риски/ограничения:** автоматизация выполняется, пока запущен web-процесс
(внешнего cron нет); планировщик по умолчанию выключен — включается
`AUTOMATION_ENABLED=1`; Turbopack-dev alias webpack-конфика не применяет
(дефолт 15.5 — webpack).

**Проверки:** `automation-scheduler.spec.ts` — 6 тестов (тик + лог старта,
перекрытие in-flight, stop ждёт in-flight, stop-до-start безопасен, нет тиков
после stop, reject → onError); dev-smoke с `AUTOMATION_ENABLED=1`:
`[automation-scheduler] started (tickMs=60000)`, страницы 200, auth-гейт 302,
без флага планировщик не стартует; web suite — 52 файла / 378 тестов; 
validation — PASS.

**Код:** `web/lib/server/automation-scheduler.ts`, `web/instrumentation.ts`,
`web/edge-register-stub.ts`, `web/middleware.ts`, `web/next.config.ts`,
`web/test/unit/automation-scheduler.spec.ts`.

---

## Android: ребрендинг «Печь» + Fix #61 — levelProgress как доля 0..1
**Дата:** 2026-10-24. Issues #67, #61; контракт доли — #54.

**Что сделано:**
- Ребрендинг «Печь» (#67): тема-токены — палитра Graphite/Violet/Lime/Flame →
  Oven/Tomato/Basil/Cheese (тёплая пиццерийная айдентика: тёмная тема — тёплый
  графит, светлая — сливочная бумага), ремап `colorScheme`
  (+`tertiaryContainer` в обеих темах), новая форма `ArtelShapes.hero`
  (асимметричный «кусок пиццы», 32/32/32/12dp); анимации в `Common.kt` —
  `rememberPressScale` (springy press), `HeroTile` (bento-плитка с
  hairline-бордером), `ShimmerBlock`/`ShimmerLoadingState` (shimmer-скелетон
  вместо спиннера); адаптированы корень и 8 экранов. Логики нет — чистый UI.
- Fix #61: сервер отдаёт `levelProgress` как долю 0..1 (контракт #54), клиент
  объявлял поле как `Int` и повторно делил на `nextLevelXp` — кольцо прогресса
  на дашборде почти всегда показывало ~0. `ApiModels.kt`:
  `levelProgress: Double`; `DashboardScreen.kt`:
  `progress = levelProgress.toFloat().coerceIn(0f, 1f)`, деление убрано.
  Текст `"$xp / $nextLevelXp XP"` не тронут — он из `Int`-полей.

**Риски/ограничения:** Kotlin-тестов в проекте нет — проверка сборкой и
валидацией; прочие правки Android в батче — UI-полировка без логики.

**Проверки:** `:app:assembleDebug` — BUILD SUCCESSFUL (Gradle 8.13, JDK 21,
APK 17.4 MB); серверный контракт пинится тестом
`levelProgress >= 0 && <= 1` (`gamification.test.ts`); validation #61
(code-reviewer + test-engineer) — PASS.

**Код:** `android/app/src/main/java/ru/memo7/artel/ui/theme/{Color,Theme}.kt`,
`android/.../ui/components/Common.kt`, `android/.../ui/ArtelRoot.kt` + экраны,
`android/.../data/api/ApiModels.kt`,
`android/.../ui/screens/dashboard/DashboardScreen.kt`.

---

## Fix #103 — inbound rate-limit: per-hook бюджеты + глобальный кап только для перебора id
**Дата:** 2026-10-24. Issue #103 (security P1); ревизия по Val103CR/Val103SA2.

**Что сделано:**
- Счётчик неудач приёма `POST /api/integrations/inbound/[id]` был один на процесс:
  30 неудач против хука #1 отдавали `429` хуку #2 (cross-hook DoS 30 запросами/5 мин),
  а «сброс успехом» сам блокировался. Вечного lockout'а не было и раньше — fixed-window
  сбрасывается по времени; дыра была именно в отсутствии изоляции хуков.
- Per-hook бюджеты: `Map<hookId, {fails, resetAt}>` в `globalThis` (переживает HMR),
  30 неудач хука → `429` + `Retry-After` до конца окна (5 мин). К хуку относятся 401/400
  (включая fail `handleInboundEvent`) и 404 несуществующего id; 413/обрыв тела счётчики
  не двигают (как и было). Успешная подпись сбрасывает бюджет только своего хука.
- Глобальный abuse-guard поднят 30 → 200/5 мин и скоуплен до перебора id (Val103CR):
  гейт — только для невалидного id (до чтения тела) и неизвестного хука (после `getHook`);
  неудачи известного хука глобальный счётчик не наполняют и им не блокируются — мусор
  по чужим id не отзывается `429` на легитимные подписанные доставки.
- Карта бюджетов капится 1000 записями: истёкшие окна вычищаются; при полной карте живых
  бюджетов новый id остаётся без учёта (skip tracking), чужие живые бюджеты не вытесняются.
- Документация: `docs/AUTHORIZATION.md` — двухуровневая схема + accepted-risk F2.

**Риски/ограничения:** accepted-risk F2 — адресный lockout конкретного хука (30 мусорных
подписей/5 мин) возможен: это цена любого per-key rate-limit; митигации — мониторинг `429`,
ротация/DELETE хука. Состояние in-memory per-process (сброс рестартом, не per-IP) — как у
логина, сознательно. Skip-tracking достижим только при ~1000 живых бюджетов/окно — перебор
id раньше закрывает глобальный кап 200.

**Проверки:** `inbound-webhooks-route.spec.ts` — 25 тестов (было 22; новые: изоляция
хуков + доставка в #6 → 200 при #5 в 429; глобальный кап — 200 невалидных id → перебор
429 при проходящей доставке в известный хук; skip-tracking карты; усилены тесты окна
и сброса успехом); `pnpm --filter web typecheck` чисто; validation — Val103SA2 PASS
(док-блокер закрыт этой записью).

**Код:** `web/app/api/integrations/inbound/[id]/route.ts`,
`web/test/unit/inbound-webhooks-route.spec.ts`, `docs/AUTHORIZATION.md`.

## Fix #97 — inbound replay: опциональный x-artel-timestamp (±300 с) + зафиксированные решения
**Дата:** 2026-10-24. Issue #97 (security P3); Val97SA PASS.

**Что сделано:**
- Оценка replay-риска: подпись `x-artel-signature` покрывает только тело —
  перехваченную валидную доставку можно повторить, дедупа по id события нет.
  Для текущей модели угроз (отправители — внутренние сервисы + ручной curl,
  bind loopback, HMAC + rate-limit #103) повтор принят как осознанный риск;
  зафиксирован в `docs/AUTHORIZATION.md` (inbound-раздел).
- Опциональный `x-artel-timestamp` (Unix ms): нет заголовка — прежнее поведение
  (контракт подписи не менялся, отправители не ломаются); есть — принимается
  только при `|now − ts| ≤ 300 с`, иначе 400 «stale/invalid timestamp». Гейт
  после успешного HMAC (не oracle) и до мутации; провал двигает per-hook бюджет —
  массовый повтор захваченной доставки (старый ts в повторе) уходит в 429.
- Граница механизма (осознанно): это дедуп наивного повтора байт (ретрай,
  переигрывание из очереди/лога), а НЕ защита от активного MITM — ts не входит
  в подпись, повторщик может подменить его или просто снять заголовок. Для
  loopback достаточно; при выносе наружу — nonce с хранилищем или подпись
  заголовков (новый контракт, отдельное решение).
- Решение по 404-vs-401 oracle (#92) зафиксировано: 404 «hook not found» vs
  401 «invalid signature» — различение сохраняется (диагностика для интегратора),
  перебор id гасится лимитами, схлопывание 404→401 перебор бы не остановило.
- Документация: `docs/AUTHORIZATION.md` — replay-абзац, oracle-решение,
  рекомендации отправителям (ставить ts один раз при отправке).

**Риски/ограничения:** см. границу механизма выше; рассинхрон часов отправителя
>±300 с даёт 400 и выжигает per-hook бюджет (429 после 30 фейлов) — мониторинг
`429` на inbound-пути.

**Проверки:** `pnpm --filter web test` — 452 теста passed, включая 7 новых
(no-header → 200; fresh → 200; stale/future/garbage → 400 без мутации; bad sig +
мусорный ts → 401; массовый повтор → 429); `pnpm --filter web typecheck` чисто;
validation — Val97SA PASS.

**Код:** `web/app/api/integrations/inbound/[id]/route.ts`,
`web/test/unit/inbound-webhooks-route.spec.ts`, `docs/AUTHORIZATION.md`.

## Feature: /style — истории-пресеты, тон и формат вместо «режима грубости»
**Дата:** 2026-10-25. Профиль «Бизнес-фича» (AGENTS §13.3).
**Issue:** #110, milestone `run-2026-10-25-product`.

**Что сделано:**
- Продуктовая модель /style разведена на две оси: «Тон» (Утешить / По-свойски /
  Разнести) и «Формат» (Пусть агент решит / Разбор / Эссе / Инструкция /
  Антипаника). Абстрактные «мягко/обычный/жёстко» и «пост-разбор/гайд/
  успокоительное» заменены на понятные сценарии и подписи.
- Примеры стали историями: заголовок, настроение, исходник и готовый пресет
  (тон + формат + подпись). Клик подставляет всё сразу и фокусирует textarea;
  карточки показывают, что получится.
- Добавлена витрина «было → стало» на одном факте про парковку: продукт
  объясняется до ввода текста, а не легендой из лейблов.
- Подпись объяснена превью «Антоновайзер, быть добру. Подписаться.» и текстом,
  что это ритуальная концовка канала; движок подписан «Где считать» с
  пояснением «быстрее / без внешнего API».
- Общие контролы вынесены в `components/style/StyleControls`: публичный /style
  (светлый мир) и студия /antonov (тёмная админка) больше не расходятся.
  В студии примеры скрыты в режиме потока; история показывает тон и формат.
- Промпт: `MODE_LABEL`/`FORMAT_LABEL` переписаны под тон/формат, в
  system-промпт добавлен инвариант «тон меняет жёсткость, но не адресата —
  читатель всегда свой». Обновлены dashboard-описания и
  `docs/auantonov-rewrite-prompt.md`.
- E2E-селекторы /antonov обновлены под новые подписи; юнит-ожидания
  user-промпта — под ПО-СВОЙСКИ/ИНСТРУКЦИЯ.

**Проверки:** `pnpm --filter web typecheck` — чисто; `pnpm --filter web exec
vitest run --maxWorkers=2` — 456 passed; `pnpm --filter web build` — успешно;
visual smoke /style в Chromium: светлая/тёмная темы, пресет «Парковка»
подставляет текст + тон + формат + подпись, контраст выбранных карточек и
витрины проверен; `pnpm --filter web exec playwright test e2e/antonov.spec.ts` —
4 passed (auth через локальный `.env`, значения не логировались);
`node scripts/loop-metrics.mjs --milestone run-2026-10-25-product` — 1 issue,
closed 0, asked-user 1, метрика неполная до commit.

**Риски:** tone/format — прежние enum-контракты API; менялись только подписи и
промпт-тексты, поэтому старые сохранённые истории студии совместимы. E2E
/antonov пройден на dev-сервере; production-сборка проверена отдельно.

**Код:** `web/data/style.ts`, `web/app/style/*`,
`web/app/components/style/StyleControls.tsx`, `web/app/antonov/page.tsx`,
`web/lib/server/style-prompt.ts`, `web/app/dashboard/page.tsx`,
`web/test/unit/*`, `web/e2e/antonov.spec.ts`,
`docs/auantonov-rewrite-prompt.md`.

## Execution loop: Android ↔ web parity + UX-фиксы (2026-10-25)
**Дата:** 2026-10-25. Профиль «Бизнес-фича» + bugfix (AGENTS §13.3–§13.4).
**Milestone:** `run-2026-10-25-android`; epic #111.
**Issues:** #105–#109, #112–#117, #120–#122, #124–#128.

**Что сделано:**
- Android core flow: `PATCH /api/workspace/items/{id}` вместо коллекции (был 405),
  refresh списка после toggle, per-item in-flight guard, ошибки — в snackbar;
  cancellation больше не маскируется под сетевую ошибку в `ArtelRepository`.
- Automation: nullable `blogSlug`, `stylePreset` (`default|antonov`) через
  `PATCH /api/blogs/{slug}` с mobile Bearer, пресеты интервала до 1440 мин,
  сохранение исходного значения, `SnackbarHost`/`Channel`.
- Новые экраны: «Геймификация» (XP-журнал + достижения, вход с дашборда) и
  «Задачи» (список, повтор, complete/dismiss/delete).
- Календарь: локальный refresh отделён от Google sync, sync заблокирован без
  Google, `.ics`-экспорт через FileProvider/share sheet, русские подписи
  источников, prune старых файлов, ошибки share.
- Уведомления: SQLite-даты как UTC → локальное время, корректные типы,
  `markRead(id)` и безопасный http(s)-`href`.
- Android UX: 401 на Connect, отдельная ошибка FAQ, лимит 2000 у ассистента;
  полная маска токена с авто-скрытием через 20 с; сброс формы поддержки.
- Дизайн: AA-контраст achievement-карточек (inverted pills, полная
  непрозрачность), icon-only bottom nav на 320dp/fs1.3, полный accent-заголовок,
  русская плюрализация счётчиков, системные бары по теме приложения (включая
  API 26–28).
- Web: `tgVisibleText` для уведомления/превью/истории (литеральные `< >` и
  `parseMode:none`), Field-label на `/integrations`, header без overflow
  640–1024px, тесты DELETE-границ и дефолтного publish-пути.

**Проверки:** `pnpm --filter challenge typecheck` + 239 tests; `pnpm --filter
web typecheck` + 482 tests; `pnpm --filter web build` — 48 страниц; Android
`:app:assembleDebug :app:testDebugUnitTest` — 40 tests / 12 классов;
Playwright `header.spec.ts` 9/9, `composer.spec.ts` — 14 passed/1 pre-existing
skip; E2E в эмуляторе Android: connect, dashboard, gamification, todos,
projects + toggle, automation style/1440, calendar refresh/.ics, notifications,
support, settings, dark/light и 320dp/fs1.3. Скриншоты — `.shots/android/`.

**Риски/ограничения:** web-only admin/dev-поверхности (RAG, blog, TG, MCP,
integrations, server settings) намеренно не переносились на Android; E2E шёл
против локального dev-сервера и локальной SQLite, production-сборка web
проверена build'ом, production Android-подпись/Play Store не затрагивались;
E2E-данные после прогона вычищены: проект «Android E2E» и задачи удалены,
токен с эмулятора стёрт. Остались только выключенное правило автоматизации
блога 1 (API не удаляет правила) и тестовое обращение поддержки в
`challenge/.data`.

**Код:** `android/**`, `web/lib/shared/tg-html.ts`,
`web/app/api/telegram/publish/route.ts`, `web/app/telegram/publish/TgComposer.tsx`,
`web/app/blog/posts/[id]/page.tsx`, `web/app/integrations/page.tsx`,
`web/app/components/Nav.tsx`, `web/app/api/blogs/[slug]/route.ts`,
`web/test/**`, `challenge/src/core/agents/automationRun.test.ts`.

## Android: вход по паролю вместо URL/API-токена (2026-10-25)
**Дата:** 2026-10-25. Профиль «Бизнес-фича».

**Что сделано:**
- `POST /api/mobile/login`: пароль рабочего пространства
  (`WEB_ADMIN_PASSWORD`) → stateless session-токен (тот же `createSessionValue()`,
  HMAC, TTL 7 дней); cookie не выдаётся. Rate-limit общий с `/api/auth/login`
  (10 неудач / 15 мин, `Retry-After: 900`), 503 при незаданном auth-env.
- `isMobileAuthed` принимает session-токен как `Authorization: Bearer` наравне
  со статическим `MOBILE_API_TOKEN` (остаётся для автоматизации). Входной
  endpoint добавлен в `PUBLIC_PATHS`; остальные `/api/*` по-прежнему закрыты.
- Android: адрес сервера зашивается при сборке
  (`-Partel.serverUrl=...`, в APK не коммитится); первый экран — только
  «Пароль» + «Войти», без «Адрес сервера»/«API-токен». Токен сохраняется
  в DataStore только после успешного `bootstrap`; 401 очищает сессию и
  возвращает на вход. Версия 1.0.1 (versionCode 2).
- Android: после успешного входа состояние `ConnectViewModel` сбрасывается —
  иначе после logout/401 экран входа оставался с busy-спиннером и старым
  паролем (P1, найден ревью и подтверждён на эмуляторе). 401 теперь чистит
  токен только если он всё ещё тот, которым шёл запрос (`clearTokenIf`), —
  поздний ответ старого запроса не разлогинивает после повторного входа.
- Docs: контракт в `docs/api-contracts.md`, `docs/AUTHORIZATION.md`
  (мобильный Bearer, границы `requireAuth`, отсутствие отзыва),
  пояснение в `.env.example`, обновлённый `android/README.md`.

**Проверки:** `pnpm --filter web typecheck` — чисто; `pnpm --filter web exec
vitest run --maxWorkers=2` — 516/516 (+23 теста: Bearer-middleware, TTL/подмена
exp, частичный env, общий rate-limit, cookie-вход); `pnpm --filter challenge
typecheck` — чисто; Android `:app:testDebugUnitTest :app:assembleDebug` —
успешно; эмулятор: неверный пароль → сообщение 401, верный пароль → дашборд
с реальными данными, logout в том же процессе → чистый экран входа с активной
кнопкой, повторный вход работает; финальный APK с Tailscale-адресом проверен
на эмуляторе против dev-сервера, поднятого на tailnet-интерфейсе.

**Риски/ограничения:** сборка debug, HTTP только внутри tailnet; production
требует HTTPS и release-подписи. Сервер должен быть запущен и доступен с
телефона по Tailscale; вне tailnet приложение не подключится. Пароль — общий
админский, на устройстве не хранится; сессия живёт 7 дней, затем вход
повторяется. Публичный доступ «любому установившему» потребовал бы отдельного
демо-режима/ролей и намеренно не открыт.

**Код:** `web/app/api/mobile/login/route.ts`,
`web/lib/server/loginRateLimit.ts`, `web/lib/auth.ts`, `web/middleware.ts`,
`web/app/api/auth/login/route.ts`, `web/test/unit/mobile-*.spec.ts`,
`web/test/unit/auth-login-route.spec.ts`,
`web/test/unit/login-rate-limit.spec.ts`, `docs/AUTHORIZATION.md`,
`android/app/build.gradle.kts`,
`android/app/src/main/java/ru/memo7/artel/ui/screens/connect/ConnectScreen.kt`,
`android/.../data/api/AuthApi.kt`, `android/.../core/network/ApiFactory.kt`,
`android/.../data/CredentialsStore.kt`, `android/.../data/ArtelRepository.kt`,
`android/app/src/test/java/ru/memo7/artel/data/NormalizeBaseUrlTest.kt`,
`android/app/src/test/java/ru/memo7/artel/data/api/AuthApiContractTest.kt`,
`android/README.md`.

## Android: runbook диагностики недоступности сервера (2026-10-26)
**Дата:** 2026-10-26. Профиль «Поиск бага» (loop-run).

**Контекст:** инцидент входа Артель: корректный пароль, на экране входа
«Сервер недоступен: failed to connect to /100.66.133.56 (port 3000)
from /192.168.31.134 (port 41378) after 15000ms». Диагноз: отказ
TCP-подключения до HTTP-фазы — проблема connectivity, не аутентификации.

**Причины (стек):**
- В момент ошибки телефон шёл мимо VPN: источник сокета в ошибке —
  `192.168.31.134` (Wi-Fi/LAN), а не tailnet-адрес `100.68.6.26`; серверная
  Tailscale-панель показывала телефон `offline, last seen 2h ago`. Пакеты к
  `100.66.133.56` (CGNAT 100.64/10) уходили в домашний шлюз и терялись →
  `SocketTimeoutException` на 15s `connectTimeout` (`ApiFactory`).
- Штатные web-скрипты bind'ят сервер только на `127.0.0.1` (`-H` в
  `web/package.json`), т.е. при штатном запуске сервер не виден по tailnet;
  приёмка Android-фичи 2026-10-25 использовала ручной запуск
  `next dev -H <tailscale-ip>`, который ни один скрипт репо не воспроизводит.
- На момент диагностики на `:3000` не слушал никто (сервер не запущен).

**Сделано:** `android/README.md` — чеклист «Сервер недоступен: failed to
connect … after 15000ms»: сервер запущен → bind на доступный телефону адрес
(Tailscale-IP или `tailscale serve`) → VPN на телефоне (адрес источника из
`from /<ip>` в ошибке) → firewall → cleartext в release. Код не менялся;
`dev`/`start` с `-H 127.0.0.1` сохранены по правилу loopback-bind.

**Проверки:** сервер поднят `pnpm --filter web exec next dev -H
100.66.133.56`; `Test-NetConnection 100.66.133.56 -Port 3000` — True
(до фикса False); `GET /` → 200; `POST /api/mobile/login` с `{}` → 400
`{"ok":false,"error":"Required"}`. С телефона не проверялось: телефон
offline в tailnet на момент диагностики — осталось включить Tailscale на
телефоне. Firewall-правило для порта 3000 автоматически не добавлено
(нужны права администратора): node.exe уже разрешён inbound (Private/
Public), интерфейс Tailscale = Private.

**Риски:** dev-режим на tailnet-IP — персональная деплой-модель Артель
(HTTP внутри tailnet + парольный вход); без VPN с телефона сервер
недоступен по определению. IP сервера не коммитится: в docs только
плейсхолдер. Для release/GPS-вне-tailnet — HTTPS за reverse-proxy
(`tailscale serve` как минимальный вариант).

**Код:** `android/README.md`, `CHANGELOG.md` (docs-only).

## Блоги: шпаргалка по управлению на сайте и в Android (2026-10-26)
**Дата:** 2026-10-26. Профиль «Бизнес-фича». Запрос пользователя: короткая
памятка на самой странице управления, читаемая с телефона на сайте и в
приложении, вместо отдельного MD-файла.

**Что сделано:**
- Страница `/blog/settings` переименована в «Управление блогами» и получила
  карточку «шпаргалка · как пользоваться»: 5 шагов (выбор блога, промпты,
  разовый пост, расписание, проверка результата), предупреждение о безопасном
  режиме черновиков и раскрываемый блок с Telegram-командой
  `/пост <блог> [publish] <тема> [| комментарий]` и частыми вопросами.
- `/blog/settings` добавлена в группу «блог» боковой/мобильной навигации —
  раньше страница была доступна только из empty-state «Постов».
- Android: в `AutomationScreen` первым элементом списка добавлена свёрнутая
  карточка «Шпаргалка» с теми же 5 шагами под возможности приложения и кнопкой
  «Открыть веб-настройки» (сохранённый base URL + `/blog/settings`); при пустом
  списке правил карточка остаётся видимой.
- Удалённого управления в Android нет намеренно: промпты и расписание живут на
  сайте, приложение только ведёт к ним и объясняет публикацию/запуск.

**Проверки:** `pnpm --filter web typecheck` — чисто; focused
`blog-cheatsheet.spec.tsx` — 2/2; полный web Vitest — 536/536 (69 файлов);
`pnpm --filter web build` — 49 страниц, `/blog/settings` в маршрутах;
Playwright-smoke на viewport 390×844 (вход, страница, раскрытие FAQ, команда) —
1 passed; Android `BlogHelpTest` (4 теста: шаги, команда, URL, пустой base URL)
и полный `:app:testDebugUnitTest` — 50/50, `compileDebugKotlin` без новых
предупреждений; challenge typecheck + 268/268 (без изменений в core).

**Риски/ограничения:** шпаргалка — статический текст; при смене TG-синтаксиса
или шагов её нужно править синхронно в `BlogCheatSheet.tsx` и
`AutomationScreen.kt`. Android-ссылка открывает браузер и требует доступного
с телефона сервера (та же tailnet-модель, что у входа). Полный web-прогон,
запущенный параллельно с Gradle/build, один раз упал на таймаутах воркеров;
последовательный прогон с `--maxWorkers=2` — 536/536.

**Код:** `web/app/blog/settings/{page.tsx,BlogCheatSheet.tsx}`,
`web/data/nav.ts`, `web/test/ui/blog-cheatsheet.spec.tsx`,
`web/e2e/blog.spec.ts`,
`android/app/src/main/java/ru/memo7/artel/ui/screens/automation/AutomationScreen.kt`,
`android/app/src/test/java/ru/memo7/artel/ui/screens/automation/BlogHelpTest.kt`.

---

## Feature: курс I2N #8 — импорт транскрипций в web и Android (2026-10-26)
**Дата:** 2026-10-26. Профиль: `business-feature`.

**Задание:** импортировать 6 видео I2N Challenge #8 (вступление + недели 1–5)
в проект, чтобы смотреть уроки в web (`/course`) и Android («Артель»), в двух
уровнях контента: очищенная транскрипция с таймкодами и курированные выдержки
с пояснениями (что/зачем/какую боль закрывает).

**Сделано:**
- Core: `CourseDb` (таблицы `lessons`/`sections`/`excerpts`, транзакционный
  `upsertLesson`) и `courseImport` (slug из имени файла, парсинг
  `*.transcript.json`, группировка utterance'ов в секции ~180с с оверлапом и
  склейкой коротких хвостов, метаданные из `challenge/src/data/course/<slug>.json`).
- CLI: `course-import <dir> [--meta <dir>]`; база `challenge/.data/course.sqlite`
  засеяна 6 уроками с выдержками.
- Web: server-компоненты `/course` и `/course/[slug]` (через `getCourseDb` +
  `withDb`), навигационная группа `course`, GET-роуты
  `/api/course/lessons[/{slug}]` под админ-gate (cookie/Bearer).
- Android: DTO + `@GET api/course/lessons[/{slug}]`, кэш списка в
  `ArtelRepository`, экраны `CourseScreen` (карточки уроков) и
  `CourseDetailScreen` (зачем/боль + выдержки + транскрипция с таймкодами),
  роуты `course`/`course/{slug}`, тайл «Курс» на дашборде.

**Проверки:** challenge typecheck + 280/280 (12 — course-тесты); web typecheck +
Vitest 541/541 (включая `course-lessons-route.spec.ts` 5/5); `pnpm --filter web
build` — `/course` и `/api/course` в маршрутах; Android `compileDebugKotlin` и
`assembleDebug` — без ошибок (JDK 21 из `artel-tools`).

**Риски/ограничения:** страницы курса и API закрыты middleware (админ-cookie или
Bearer-токен) — анонимный просмотр недоступен; выдержки — статические JSON в
репозитории, при новом видео их нужно добавить вручную; Android не кэширует
деталь урока офлайн (список — в памяти, детали — всегда по сети).

**Код:** `challenge/src/core/courseDb.ts`, `challenge/src/core/courseImport.ts`,
`challenge/src/data/course/*.json`, `challenge/src/cli.ts`,
`web/app/course/`, `web/app/api/course/`, `web/data/nav.ts`,
`web/lib/server/{db,challenge}.ts`,
`android/.../ui/screens/course/`, `android/.../data/api/{ApiModels,ArtelApi}.kt`,
`android/.../data/ArtelRepository.kt`, `android/.../ui/ArtelRoot.kt`,
`android/.../ui/screens/dashboard/DashboardScreen.kt`.

---

## Android: вход как на сайте — адрес сервера вводится в приложении (2026-10-26)
**Дата:** 2026-10-26. Профиль «Бизнес-фича» (loop-run), milestone run-2026-10-26.

**Задание:** приложение должно быть пригодно для любых пользователей — так
же, как любой может открыть сайт: адрес рабочей области вводит сам
пользователь (как URL сайта в браузере), админка под паролем. Механика
«адрес зашивается при сборке через `-Partel.serverUrl` →
`BuildConfig.DEFAULT_SERVER_URL`, поле адреса скрыто» удалена полностью.

**Что сделано:**
- Android: `ConnectViewModel` без параметра `bakedServerUrl` и флага
  `hasBakedUrl`; поле «Адрес сервера» всегда показывается и редактируется;
  последний успешный адрес подставляется безусловно (и после
  logout/401) из DataStore (`lastServerUrl`). Placeholder нейтральный
  `https://artel.example.com`, клавиатура URL.
- Android: чистый `ConnectRules` (валидация ввода + человекочитаемые
  причины сбоев: unresolved host / cleartext в release / таймаут-подключение)
  — VM-ветки `IOException` Login и bootstrap теперь дают конкретную
  подсказку, а не сырой `e.message`; +9 юнит-тестов.
- Gradle: удалены baked-блок и `buildConfig = true` (BuildConfig больше
  никем не используется); версия 1.1.0 (versionCode 3).
- Docs: `android/README.md` — механика «адрес + пароль» без зашивания;
  `docs/api-contracts.md` — то же в контракте мобильного входа.

**Проверки:** Android `:app:testDebugUnitTest :app:assembleDebug` —
successfully, 55 юнит-тестов (+9 `ConnectRulesTest`); `git diff` — только
файлы задачи. Web/challenge не менялись (typecheck из предыдущего прогона —
чисто).

**Риски/ограничения:** как и прежде: сервер по адресу, который ввёл
пользователь, должен быть запущен и доступен с телефона (LAN/Tailscale);
cleartext только в debug-сборках, release требует https-адреса. Полный
паритет экранов приложения с web-админкой (rag/chat/tg/blog/mcp/sys/
integrations) — backlog в issue эпика (milestone run-2026-10-26).

**Код:** `android/app/build.gradle.kts`,
`android/.../ui/screens/connect/ConnectScreen.kt`,
`android/.../ui/screens/connect/ConnectRules.kt`,
`android/app/src/test/java/ru/memo7/artel/ui/screens/connect/ConnectRulesTest.kt`,
`android/README.md`, `docs/api-contracts.md`.

---

## Android: чат — MVP-паритет web /chat (2026-10-26)
**Дата:** 2026-10-26. Профиль «Бизнес-фича» (loop-run), milestone
run-2026-10-26, стори #137 эпика #134 (паритет web↔app).

**Задание:** функциональный блок «Чат» в приложении «Артель»: те же сессии, что
на web `/chat` — список, создание с выбором стратегии памяти и системного
промпта, переписка с живым SSE-стримингом, остановка генерации, сброс
истории. Скоуп MVP не включает `joker/antonov`, панели
memory/branch/profile/constraints — они остаются в backlog эпика.

**Что сделано:**
- Чистый SSE-парсер `data/api/ChatStream.kt`: безымянные события
  `data: <JSON>` через `\n\n` (контракт web `web/lib/shared/sse.ts`:
  `token{delta}` / `done{answer,usage}` / `error{message}`; конец потока —
  закрытие соединения, `[DONE]`-сентинела нет). Session-feed API
  (`drain`), битые/неизвестные события молча пропускаются.
- Репозиторий: `chatSessions`, `createChatSession`, `chatSession`,
  `resetChatSession` (Retrofit) и `chatStream` — OkHttp напрямую
  (readTimeout 0, connect 15 c, Bearer как в остальных запросах; 401
  очищает токен той сессии, что шла в запрос — как в общем каркасе).
  Отмена стрима (`cancelChatStream`) — кнопка «Остановить»; okhttp call
  cancel не роняет UI: partial текст остаётся в пузыре.
- Экраны: `ChatsScreen` (список сессий + диалог создания: стратегия
  full/sliding/sticky/branching, системный промпт ≤2000) и `ChatScreen`
  (история из GET /api/chat/[id] без системных реплик, пузыри со
  стрим-текстом, стоп, сброс с подтверждением, счётчик токенов в шапке).
  Вход: карточка «Чат» на дашборде + маршруты `chat` / `chat/{sessionId}`.
- Тесты: `ChatStreamTest` (5 кейсов парсера: последовательность,
  чанки-дописывание, битый JSON, неизвестные события, пробелы после
  `data:`), `ChatContractTest` (декодирование сессии/списка, кодирование
  запросов).

**Проверки:** `:app:testDebugUnitTest :app:assembleDebug` — зелёные;
контракт — против реальных строк SSE-формата из
`web/app/api/chat/[sessionId]/route.ts` (data-prefix, `\n\n`, три типа
событий). Diff — только файлы чата. Новых зависимостей НЕТ (okhttp-sse не
добавлялся — парсер ручной).

**Риски/ограничения:** usage в стриме — аппроксимация сервера (символы/4);
при 401 экран остаётся с ошибкой, повторный вход — как для остальных
разделов; панели памяти/веток прикреплены к следующим стори эпика #134.

**Код:** `android/.../data/api/ChatStream.kt`,
`android/.../data/api/ApiModels.kt` (chat-секция),
`android/.../data/api/ArtelApi.kt`, `android/.../data/ArtelRepository.kt`,
`android/.../ui/screens/chat/ChatsScreen.kt`,
`android/.../ui/screens/chat/ChatScreen.kt`,
`android/.../ui/ArtelRoot.kt`,
`android/.../ui/screens/dashboard/DashboardScreen.kt`,
`android/app/src/test/java/ru/memo7/artel/data/api/ChatStreamTest.kt`,
`android/app/src/test/java/ru/memo7/artel/data/api/ChatContractTest.kt`.

---

## Feature: курс — недели 8–9 Advanced-потока (полная транскрипция + выдержки) (2026-10-26)
**Дата:** 2026-10-26. Профиль: `business-feature`, loop-run, milestone `run-2026-10-26`.

**Задание:** добавить в базу знаний курса транскрипции «8 неделя 1 поток
адвансд» и «9 неделя 1 поток адвансд» — так же, как предыдущие уроки:
полная транскрипция с таймкодами + курирование (summary/why/pain/выдержки),
чтобы уроки были видны и понятны в web (`/course`) и Android («Артель»).

**Сделано:**
- Конвертация md-транскриптов в формат импортера
  `*.transcript.json` (utterances `MM:SS → ms`, end = start следующего,
  длительность 24:59 и 28:31) — источники в `challenge/.data/course-sources/`
  (вне git), 74 и 28 абзацев.
- Курирование: `challenge/src/data/course/week-8.json` (код-ассистент:
  main-агент, субагенты, скиллы/команды/хуки, правила open–close, профили,
  инварианты, Task State, Execution Loop, MCP-набор) и `week-9.json`
  (файн-тюнинг: attention/LoRA/QLoRA, датасеты, оверфиттинг, границы
  применимости), по 10 выдержек каждая.
- Импорт CLI `course-import` — в course.sqlite добавлены week-8 (10 секций)
  и week-9 (26 секций); upsert идемпотентный, web/Android изменений кода
  не требуют (список строится из CourseDb, упорядочен по week_no).

**Проверки:** challenge typecheck зелёный + 280/280 тестов; web typecheck +
Vitest 541/541 (включая course-роуты); `pnpm --filter web build` — ок;
smoke через `CourseDb.getLesson/getSections/getExcerpts` — оба урока
рассекционированы (0–1 499 000 мс и 0–1 711 000 мс), выдержки на месте;
повторный импорт безопасен (упsert). Экраны курса закрыты middleware
(админ-cookie/Bearer) — как и раньше.

**Риски/ограничения:** недели 8–9 — Advanced-поток; слаги `week-8`/`week-9`
использованы напрямую и могут пересечься с будущей нумерацией основного
потока (тогда переименовать слаги отдельной задачей). Android-сборка не
прогонялась в этой сессии — нет JDK в среде; Kotlin-код не менялся.

**Код:** `challenge/src/data/course/{week-8,week-9}.json`
(данные, кода нет); драйверы импорта — уже существующие
`challenge/src/{core/courseDb.ts,core/courseImport.ts,cli.ts}`.

---

## ADVANCED Day 6 — text-to-SQL LoRA: Qwen2.5-1.5B-Instruct + QLoRA на T4
**Дата:** 2026-10-26

**Задание:**
> Узкий text-to-SQL LoRA: датасет b-mc2/sql-create-context → Qwen2.5-1.5B-Instruct
> → QLoRA на облачной T4. Adapter, run.json, loss-кривая и сравнение base vs
> tuned на 20 запросах, включая блок «где стало хуже». Формат: видео + код.

**Сделано:**
- Пайплайн `training/day-06/`: `prepare_data.py` (stdlib-only: скачивание,
  чистка, group split), `train_qlora.py` (QLoRA NF4 r=16, маска loss на
  assistant-токенах, loss.csv/run.json, early stopping), `evaluate.py`
  (20 промптов, base vs tuned на одной загрузке через `disable_adapter`,
  метрики sqlglot + SQLite EXPLAIN, report.md/html + regressions.md),
  `plot_loss.py`, `configs/qlora.yaml`, `requirements.txt`, optional `make_gguf.sh`.
- Факты датасета проверены локальным прогоном (не из описания HF): 78 577
  строк, 72 947 уникальных schema, 0 дублей, 1 конфликтующая пара (MIN/MAX),
  100% SELECT, контекст avg 71.6/p99 149, ответ avg 76.3/p99 166, `IS NULL`
  нет (NULL — строковый литерал).
- Group split по sha1(context) со стратами 1 vs 2+ таблиц: 5000/500/500;
  схемы eval-набора исключены из всех сплитов. Проверено: пересечений
  сплитов 0, утечек eval 0. В ходе проверки найден и исправлен баг квот
  (train раздувался до 77k, multi-table проваливались в train).
- Eval-набор `eval/prompts.jsonl`: 10 in-domain (реальные строки датасета:
  select/filter/agg/group/join/order/subquery/null/like/multi) + 5 edge
  (невалидная колонка, неоднозначность, пустая schema, невозможный запрос,
  INSERT) + 5 OOD (чат, математика, перевод, код, русский).

**Результаты прогона (2026-10-26T20:13Z, Tesla T4):**
- Обучение: 2 эпохи, 5 000 train / 500 val, 46.4 мин (2 781.7 с), финальный
  train loss 0.0208, eval loss 0.0407, best checkpoint-600, VRAM ≤ 2.68 ГБ.
- Eval на 20 фиксированных запросах: format_ok in-domain 10/10 (base 0/10),
  exact match in-domain 7/10 (base 0/10), schema_ok 10/10 (base 0/10),
  format_ok по всем 18/20 (base 3/20), regressions (edge+ood) 5/10,
  latency avg 1319 → 1704 мс.
- Полные артефакты: `docs/advanced-day-06/eval/` (`run.json`, `report.md`,
  `report.html`, `regressions.md`, `results.jsonl`, `loss.csv`, `loss.png`);
  сводка — `docs/advanced-day-06/README.md`.

**Ограничения:** 5 регрессий из 10 ожидаемы (catastrophic forgetting,
over-SQL/select-bias, hallucinated column) и разобраны в `regressions.md`;
ручная оценка 1–5 (fmt/corr/adh) в `report.md` не заполнена — автоматика её
не подменяет. LoRA-адаптер пока не опубликован (лежит только в Kaggle-output):
TODO — issue #143 (HF Hub / GitHub Release).

**Код:** `training/day-06/**`, `docs/advanced-day-06/{README,video-script}.md`,
`docs/advanced-day-06/eval/*`.

---

## Feature: аркада 2.0 — XP, уровни, 7 достижений и шеринг (2026-10-29)
**Дата:** 2026-10-29. Ветка `web/arcade-review-fixes` (мерж `df5a8e9`).

**Задание:** довести игры `/showcase` до продуктового прогресса: XP и уровни,
достижения, сохранение между визитами и шеринг результата/профиля.

**Сделано:**
- `progress.ts` — чистая логика: XP за долю правильных ответов
  (quiz 40 / layers 20 / stack 30 / sim 25 за 100%) + `bonusXp`;
  6 уровней (`LEVEL_THRESHOLDS` 0/40/100/180/280/400 с титулами);
  7 достижений (`first-steps`, `sharp-eye`, `architect`, `librarian`,
  `chief-editor`, `all-rounder`, `rising-star`), выдача в `recordResult`.
- `use-progress.ts` — localStorage `arcade.progress.v1`, сужение чужих данных
  (конечные неотрицательные числа, известные id игр/достижений), sync по
  `storage`, CustomEvent `arcade:progress`; `ProgressPanel.tsx` показывает
  уровень, XP-бар, лучшие результаты и достижения; игры репортят результат
  через `reportResult`.
- `share-card.ts` — текст результата/профиля и ссылка `t.me/share/url`
  (фолбэк на Web Share — URL).
- Тесты: `test/unit/{arcade-progress,share-card}.spec.ts`,
  `test/ui/progress-panel.spec.tsx`, `e2e/arcade-progress.spec.ts`.

**Проверки:** `pnpm --filter web typecheck`; Vitest 654/654 после мержа;
`pnpm --filter web build` — 0 ошибок (2026-10-29). E2E-сценарий
`arcade-progress` добавлен, в этой сессии не прогонялся.

**Риски/ограничения:** прогресс живёт только в localStorage — нет серверного
профиля, очистка браузера сбрасывает XP. В `share-card.ts` `SITE_URL` зашит
на dev-адрес `http://127.0.0.1:3000/showcase`; для прод-шеринга нужен реальный
домен (отдельная задача).

**Код:** `web/app/components/arcade/{progress,use-progress,share-card}.ts`,
`web/app/components/arcade/ProgressPanel.tsx`, игры
`QuizGame/LayersGame/StackGame/ShowcaseArcade`.

---

## Feature: командная палитра Ctrl+K (2026-10-29)
**Дата:** 2026-10-29. Ветка `web/arcade-review-fixes` (мерж `df5a8e9`).

**Задание:** быстрый переход по разделам админки с клавиатуры без мыши.

**Сделано:**
- `CommandPalette.tsx` (`'use client'`) — Ctrl/Cmd+K, Enter/стрелки/Esc,
  `role=dialog` + `listbox`/`option` + `aria-activedescendant`, переход через
  `router.push`, внешние ссылки — `window.open` с `noopener,noreferrer`.
- `PaletteButton.tsx` — кнопка в `Nav` через CustomEvent `palette:open`.
- `palette-items.ts` — пункты из `navGroups` для админа + гостевой набор;
  `lib/shared/fuzzy.ts` — ранжирование по подстроке/подпоследовательности.
- Палитра подключена в `app/layout.tsx` с учётом `isAdmin`.

**Проверки:** unit `palette-items`, `fuzzy`; ui `command-palette` (входят в
Vitest 654/654 после мержа); prod build — 0 ошибок. E2E
`command-palette` добавлен, в этой сессии не прогонялся.

**Код:** `web/app/components/palette/{CommandPalette,PaletteButton,palette-items}.tsx`,
`web/lib/shared/fuzzy.ts`.

---

## Feature: «Свежее в канале» на лендинге (2026-10-29)
**Дата:** 2026-10-29. Ветка `web/arcade-review-fixes` (мерж `df5a8e9`).

**Задание:** показать на `/` последние посты Telegram-канала без Bot API и
деградировать без секции, если источник недоступен.

**Сделано:**
- `web/lib/server/channel-preview.ts` (`server-only`) — выборка
  `https://t.me/s/<username>` через `netFetch`-chokepoint, парсинг
  `data-post`/`datetime`/`tgme_widget_message_text`, декодирование HTML-сущностей,
  кэш: успех 10 мин, ошибка 60 с; любая ошибка/пустой ответ → `{ ok: false }`.
- `/` (Server Component) рендерит секцию «Свежее в канале» только при
  `ok: true` и непустом списке; иначе секция целиком скрыта.
- Тесты: `test/unit/channel-preview.spec.ts` (парсинг, кэш ok/fail, деградация).

**Проверки:** Vitest; prod smoke — `/` 200, без доступного preview секция
отсутствует; `/showcase` 200.

**Риски/ограничения:** источник — HTML `t.me/s`, а не API: изменение разметки
ломает парсер (тогда секция просто скрывается). Username зашит в коде
(`@artemiyartel`), не читается из env — при смене канала нужна правка кода.

**Код:** `web/lib/server/channel-preview.ts`, `web/app/page.tsx`,
`web/test/unit/channel-preview.spec.ts`.

---

## ADVANCED Day 7 — свой датасет: NL → JSON add_todo (2026-10-30)
**Дата:** 2026-10-30. Ветка `feat/advanced-days-07-10` (loop run-2026-10-30,
эпик #152).

**Задание:**
> Свой датасет под узкую задачу с проверяемым результатом; замеры без тюна
> (база без инструкций + проработанный промпт); 200+ примеров с чисткой;
> обучение и сравнение с промптингом на eval-наборе. Формат: видео + код.

**Сделано:**
- Задача тюна: русская фраза → JSON `add_todo` (text, recurring, day_of_week
  0=вс, interval_hours); boundary-кейсы (два дня, интервалы в днях/минутах,
  абсолютные даты) — пунт (recurring=null, текст как есть). Привязка к
  продукту: NL→tool-args перед MCP `add_todo` (todoParser NL не понимает).
- Датасет в git (`training/day-07/data/`): train 463 / valid 63; сиды
  (412 шаблонных вызовов, gold по построению) + LLM-входы qwen2.5:7b-instruct
  (220 кандидатов → 160 принято, 27% отбраковано rule-валидатором, список
  брака — `data/rejected.jsonl`); чистка почти-дублей difflib ≥ 0.92 (−46);
  баланс weekly 177 / daily 122 / none 116 / hourly 111.
- Eval-набор 30 handcrafted кейсов (`eval/eval_set.jsonl`), слоты не
  пересекаются с train (assert в seeds.py); `check_split.py`: утечек 0.
- Ревью глазами 30 случайных × 3 итерации: закрыты 3 дыры валидатора
  («каждый день»+null, «полчаса»→interval_hours:30, висячий предлог в text).
- Baseline без тюна (реальный прогон 2026-10-30T16:25Z, qwen2.5:1.5b-instruct
  Ollama, temperature=0 seed=42): none — parse_ok 0/30 (JSON не выдаёт
  вовсе), prompt — parse_ok 30/30, full_match **14/30** (text 19, recurring
  19, dow 21, interval 28; по классам: weekly 7/8, hourly 4/5, daily 2/6,
  пунт 1/11), latency 2274 мс. Артефакты: `docs/advanced-day-07/eval/`.
- Код обучения: `train_qlora.py` (QLoRA NF4 r=16 α=32, fp16 для T4, маска
  assistant-токенов, MASK CHECK, early stopping, run.json с sha256 датасета);
  `evaluate_tuned.py` (tuned/base-prompt/base-none на одной 4-bit загрузке
  через `disable_adapter()`); README с Kaggle-runbook.
- Инфраструктурная находка: `ollama pull` блокируется на R2-блобах CDN —
  воркаунд GGUF с HF + `ollama create` проверен (issue #163).
- **T4-прогон выполнен** (2026-10-30, kernel `tema13002/day07-qlora-todo-t4`
  v8, GPU T4): обучение 452.9 с (~7.5 мин, ~1570 tok/s, VRAM ~3 ГБ), train
  loss 0.0056, best eval loss 0.0191 (checkpoint-90/116, эпоха ~3.1; eval
  loss ↓ монотонно — переобучения нет). Tuned vs base (один рантайм,
  temperature=0 seed=42): tuned parse_ok 30/30, full_match **14/30**
  (hourly 5/5, weekly 3/8, daily 2/6, punt 4/11) против base-prompt 10/30
  и base-none 0/30; latency 3374/1984/7004 мс. Артефакты:
  `docs/advanced-day-07/eval/tuned_*`; adapter + чекпоинты + run.json +
  loss.csv скачаны в `training/day-07/artifacts/` (gitignored).
- Инфраструктурные находки прогона (образ Kaggle теперь Python 3.13):
  pins torch 2.5.1/torchvision 0.20.1 без cp313-колёс; предустановленный
  transformers 5.16 ломает API TrainingArguments; предустановленный triton
  (3.3.1) не содержит `triton.ops`, от которого зависит bnb 0.45.0. Рабочий
  стек: torch 2.6.0 + torchvision 0.21.0 + transformers 4.46.3 + peft
  0.13.2 + bnb 0.45.0 + accelerate 1.1.1, triton удалён полностью (bnb
  стабит заглушки через is_triton_available(); 4-bit NF4 triton не нужен).

**Ограничения:** порог успеха дня — full_match ≥ 21/30 при parse_ok
30/30 — **не достигнут**: tuned 14/30 (same-runtime base-prompt 10/30,
локальный Ollama-бейзлайн prompt 14/30). Главные провалы — weekly 3/8 и
punt-None 4/11; рычаги: `--llm-batches 60` с фокусом на weekly/punt-границах,
пересмотр сэмплирования punt-класса, больше эпох при следящем eval.
Follow-up issue заведён; пункт-класс (11/30 eval) — ожидаемо самый
трудный для тюна.

**Код:** `training/day-07/**`, `docs/advanced-day-07/{README,video-script}.md`,
`docs/advanced-day-07/eval/{baseline_report.md,baseline.json,baseline_results.jsonl}`.

## ADVANCED Day 8 — границы файнтюнинга (2026-10-30)
**Дата:** 2026-10-30. Ветка `feat/advanced-days-07-10` (loop run-2026-10-30,
эпик #153, стори #164–#168).

**Задание:**
> Факты (что тюн не добавит), потери вне домена, переобучение (кривые loss,
> epoch-чекпоинты), три типа задач (формат/стиль/факты): прирост тюна vs
> прироста промпта. Формат: видео + код.

**Сделано:**
- s1 Факты (#164): 36 синтетических фактов (seed=42) + 72 вопроса
  (orig/paraphrase). base-none 0/72 (1.5b и 7b), base-prompt 42/72 (1.5b)
  и 50/72 (7b), tuned RAG-режим 45/72 (T4). Факты — в контекст, не в веса.
- s2 Потери вне домена (#165): 24 кейса (chat/math/translate/code, gold по
  построению). Цена тюна ≈ −0.08 avg (tuned 0.42 vs base-prompt 0.50 на
  T4); chat 0.33 → 0.17, математика/перевод держатся.
- s3 Переобучение (#166): свип чекпоинтов 30/60/90/116 (эпохи 1–4):
  valid 1/63 → 55/63 → 56/63 (насыщение после 1-й эпохи, деградации нет);
  eval loss ↓ монотонно до 0.0191 (step 90), расхождения нет. Нюанс:
  todo-priming лочит тюн в формат на чужих задачах (0.09 vs base 0.22).
- s4 Три типа задач (#167): единый отчёт tasks_report.md — формат:
  tuned 0.47 > prompt 0.33 > base 0.00; факты: только prompt/RAG; стиль:
  prompt нестабилен (1.5B −0.08 / 7B +0.11), тюн не переносится (−0.07).
  Style-eval — 12 кейсов с rule-скорером ограничений (без LLM-судьи).
- Инфраструктура: kernel'и Kaggle с кодом base64; чекпоинты day-07 в
  приватном датасете `tema13002/day07-checkpoints` (eval-only kernel v12
  без переобучения); eval_facts/eval_style с transformers-бэкендом
  (tuned vs base на одной 4-bit загрузке).

**Выводы:** формат/паттерны → тюн; факты/контекст → RAG; стиль → промпт
с обязательной проверкой прироста; точку останова обучения выбирать по
eval loss (1–2 эпохи достаточно на 463 примерах).

**Ограничения:** eval-наборы маленькие (24–72 кейса); facts-tuned (0.62)
и base-prompt (0.58) — разные рантаймы, сравнение качественное;
style-скорер ловит формальные ограничения, не «красоту» стиля.

## ADVANCED Day 9 — дистилляция (2026-10-30)
**Дата:** 2026-10-30. Ветка `feat/advanced-days-07-10` (loop run-2026-10-30,
эпик #154, стори #169/#170/#176/#177/#178).

**Задание:**
> Дистилляция: задача, где 1.5B уступает 7B; генерация ответов учителя с
> фильтрацией; обучение ученика (QLoRA); сравнение до/после/учитель.
> Формат: видео + код.

**Сделано:**
- s1 (#169): eval-набор 30 задач «спецификация → Python-функция» (20 базовых
  + 10 посложнее), rule-скорер (исполнение тестов в песочнице с безопасными
  builtins). Ученик до (qwen2.5-coder:1.5b-base) 24/30 (80%), учитель
  (coder:7b) 27/30 (90%).
- s2 (#170): пул 120 train-задач (12 шаблонов × 10 слотов, seed=42,
  пересечений с eval — 0); учитель сгенерировал решения локально (Ollama,
  temperature=0), rule-фильтр по тестам принял 120/100% (пул лёгкий — в
  датасет не попало ни одной ошибки учителя). Датасет в git
  (data/distill_train.jsonl, messages-формат).
- s3 (#176): QLoRA-обучение ученика (base Qwen/Qwen2.5-Coder-1.5B, стек
  day-07) на Kaggle T4, kernel tema13002/day09-distill-student-t4 v1:
  train+eval одним прогоном. Обучение 56.5 с, best checkpoint-15, final
  train loss 0.0, eval loss 4.3e-05 — зазубривание пула. Артефакты в
  training/day-09/artifacts/ (gitignored).
- s4 (#177): сравнение (compare.md): ученик после 18/30 < ученик до 24/30 <
  учителя 27/30 (рантаймы Ollama vs T4 разные, падение существенное).
  Скорость: 1.5B ~1.3× быстрее 7B; стоимость: ~1.2 ГБ против ~4.7 ГБ VRAM.
  Гипотеза «ученик заменяет учителя» НЕ подтвердилась.

**Выводы:** дистилляция лёгкого пула переносит формат, но не сложность;
eval loss ≈ 0 при memorization — плохой сигнал остановки, нужен downstream-
eval; экономика ученика реальна, но качество на unseen пока у учителя.
Рычаги: hard-mining пула, следящий eval на holdout, r=8 + dropout, sampling
учителя при t>0.

**Ограничения:** 30 задач — маленький набор (24 vs 18 значимо, 27 vs 24 —
погранично); сидирование между Ollama и transformers не совпадает; код
моделей исполнялся локально в песочнице (безопасные builtins).

## ADVANCED Day 10 — тюненая модель в проде (2026-10-30)
**Дата:** 2026-10-30. Ветка `feat/advanced-days-07-10` (loop run-2026-10-30,
эпик #155, стори #171–#175).

**Задание:**
> Merge + квантование (GGUF Q4_K_M), замеры, интеграция в сервис с
> переключением без рестарта, проверка на реальных запросах, runbook
> выката/отката. Формат: видео + код.

**Сделано:**
- s1 (#171): merge_gguf.sh (merge_and_unload FP16 → convert_hf_to_gguf →
  llama-quantize Q4_K_M + Modelfile + merge_report sha256). Kernel Kaggle
  `tema13002/day10-merge-gguf` v5: F16 3.09 ГБ → Q4_K_M 986 МБ
  (sha256 b91286ee… сверен после скачивания). Локально
  `ollama create qwen2.5-coder-1.5b-distilled`, sanity-ответ верный.
- s2 (#172): bench_model.py — память 1.2 ГБ (обе), cold-start 4312/5687 мс,
  warm avg 2191/3841 мс (разница = длина ответа), tok/s 147.0/144.5.
- s3 (#173): web runtime-переключатель local-model-switch.ts +
  /api/local-model (GET/POST, zod, allowlist, 400/409); pickLlmClient
  honor'ит override. Web typecheck чист, 11/11 Vitest.
- s4 (#174): смоук на dev-сервере 127.0.0.1:3100 — switch→tuned→agent
  (компактный код ~2.7 с)→откат→base (многословный ответ). Транскрипт
  docs/advanced-day-10/smoke.md.
- s5 (#175): runbook выката/отката, чек-лист контроля модели, подводные
  камни Kaggle (API-датасеты mount /kaggle/input/datasets/<owner>/<slug>,
  slug kernel'а из title, torchvision пара к torch, READY≠смонтирован).

**Выводы:** инфраструктурно выкат «бесплатен» (память/скорость как у base,
файл −68%); переключатель даёт мгновенный откат без рестарта; качество —
открытый риск (day-09: регресс на eval), выкат под наблюдением.

**Ограничения:** качество tuned на eval ниже base (day-09, честно
зафиксировано); бенчмарк на одном железе (RX 7600), tok/s без
промпт-паритета; переключатель процесс-локален (не кластерный).


---

## ADVANCED Days 6–10 (доработка) — «факты в весах» на CPU + понятные примеры (2026-10-31)
**Дата:** 2026-10-31. Ветка `feat/advanced-days-11-20` (loop run-2026-10-31,
milestone 8, стори #180/#181).

**Задание:** execution loop по дням 6–10: проверить, чего не хватает против
чек-листов, и доработать до максимально понятных примеров.

**Сделано:**
- Гэп-анализ: дни 6, 9, 10 закрыты полностью; день 7 закрыт с честно
  зафиксированным недобором tuned 14/30 (порог 21/30, #179 — нужен GPU-
  перезапуск с доработанным датасетом); день 8 имел пробел — протокол
  «обучить НА фактах → проба в обучающей/отличной формулировке» был снят
  только в варианте «контекст vs base».
- s1-доп (#180): `training/day-08/train_facts.py` — Qwen2.5-0.5B-Instruct +
  LoRA r=16 на CPU fp32 (venv `training/.venv`; torch 2.6.0+cpu,
  transformers 4.46.3, peft 0.13.2 — тот же стек, что рабочие Kaggle-прогоны).
  36 фактов как SFT-пары «orig-вопрос → ответ», 30 эпох (final train loss
  0.0009, стенка 588.6 с). Проба 72 вопросов в 4 режимах: trained-orig
  **26/36**, trained-para **25/36**, base-none 0/72, base-prompt 36/72 (50%).
  Отчёт «один факт — четыре режима»: `docs/advanced-day-08/eval/facts-trained/`
  (report.md, results.jsonl, facts_trained.json, loss.csv).
- Понятные примеры (#181): README day-07 — блок «один запрос — три ответа»
  (base-none рассуждает, base-prompt ломает тип `"null"`, tuned — ровно схема)
  плюс два честных провала tuned; README day-09 — реальные регрессии ученика
  (t04 `text.count(' ')`, t02 лишняя скобка, t28 один проход вместо цикла;
  полный список t02/t04/t12/t14/t23/t28 — исправлено устаревшее «t26/t28»).
- Вывод s1 «факты не достаются тюном» уточнён в обоих README дня-08:
  факты в веса закладываются, но ненадёжно (recall 26/36, ответы хрупки
  до цифры «35»→«355», привязка к упоминанию сущности, а не к форме вопроса);
  рекомендация «факты → промпт/RAG» сохраняется по управляемости.
- Инфраструктура: `.gitignore` — `training/.venv/`; `requirements-cpu.txt`
  в day-08 с инструкцией установки CPU-окружения.

**Проверки:** `pnpm --filter challenge typecheck` — чисто (TS-пакеты не
затронуты). Rule-генераторы day-08 (`gen_facts/gen_questions/gen_style`)
перепрогнаны — git diff пуст (детерминизм подтверждён);
`training/day-07/check_split.py` — OK. Оба прогона train_facts.py реальные
(4 эпохи → recall 3/36, недообучение; 30 эпох → 26/36).

**Выводы:** ассоциативное запоминание требует десятков проходов (4 эпохи →
loss ~1.0, recall 3/36; 30 эпох → loss 0.0009, recall 26/36); recall держится
на якоре-сущности в вопросе (para ≈ orig), что не эквивалентно пониманию;
промпт дороже по токенам, но мгновенно обновляется и масштабируется с
размером модели (0.5B 50% → 1.5B 58% → 7B 69%).

**Ограничения:** эксперимент на 0.5B (не на 1.5B тюна day-07) — вывод
качественный; para-переформулировки сохраняют имя сущности, вопросы «без
якоря» пробой не покрыты; адаптер эксперимента не сохранялся (демо, не продукт).

---

## Дни 6–10 (футбольный трек: АПЛ/Челси) — тюн, границы, дистилляция, прод

**Дата:** 2026-10-31

**Задание:** повторить дни 6–10 челленджа в футбольном домене: готовый
датасет → свой датасет → границы тюна → дистилляция → выкат в сервис.

**Сделано (все прогоны реальные, локально: CPU fp32, Qwen2.5-0.5B-Instruct
+ LoRA r=16; Ollama — учитель 7B и прод-рантайм):**
- **День 6** — `training/football/day-06`: HF `global-football-assistant-dataset`
  (9600 ChatML из 302 фактов), групповой сплит по fact_id, train 1300/val 160,
  обучение 41 мин, eval-20: in-domain F1 0.10→0.53, edge safety 1/5→1/5
  (регрессия d6-edge-12 зафиксирована), ood 5/5→5/5.
- **День 7** — `training/football/day-07`: свой датасет NL→JSON матча
  (318/42/30, ручной eval на слотах Челси, чек-сплиты зелёные), baseline
  prompt 4/30, tuned **11/30** (base-prompt zero-shot в том же рантайме 0/30);
  цена CPU-тренировки на длинных JSON: микро-батч 2 × accum 4 (иначе
  своп/segfault), чекпоинтинг на этой машине деградировал — не используем.
- **День 8** — `training/football/day-08`: факты в весах (orig 36/36,
  para 14/36, prompt 12/72), out-of-domain tuned 0.667 > base 0.583 (цены
  нет при нейтральном промпте), свип эпох (valid 26→29→60%, ood 0.708→0.667
  с 3-й эпохи), стиль 0.25/0.42/0.33 (JSON-тюн на стиль не переносится).
- **День 9** — `training/football/day-09`: дистилляция JSON→репортаж,
  teacher qwen2.5:7b через Ollama + rule-фильтр (87 verified из 120),
  ученик **24/30 (0.80) против учителя 21/30 (0.70)**; честный нюанс:
  latency учителя на GPU-Ollama ~4× выше, выигрыш ученика — память/размер.
- **День 10** — `training/football/day-10`: merge → GGUF f16 → **Q4_K_M
  379 МБ** (llama.cpp b12023), `ollama create qwen2.5-0.5b-football`
  (прямой импорт safetensors этим Ollama-билдом не поддержан — зафиксировано),
  бенчи (память 483/483 МБ, 143/177 ток/с), смоук переключения/отката через
  существующий `/api/local-model` (env LOCAL_LLM_*), runbook выката/отката.

**Выводы:**
- Тюн силён в формате/дисциплине домена и не требует few-shot; факты в веса
  лезут ненадёжно (перенос на парафразы ~39%); стиль-тон — территория промпта.
- Тюненая модель — контрактная: строгое поведение только с полным system
  prompt обучения (проверено в прод-смоуке).
- Дистилляция под проверяемый rule-скорер может обогнать учителя по метрике
  (ученик выучил «безопасный» формат) — и это одновременно риск переоптимизации.

**Код:** `training/football/day-06..10`, отчёты — `docs/advanced-day-06..10/football/`.

---

## Execution loop run-2026-10-31 — Android parity wave 1: RAG, Telegram, Блог, MCP
**Дата:** 2026-10-31
**Ветка:** `feat/close-open-issues`

**Задание:** стори #144–#147 эпика #134 — паритет web-админки в приложении
«Артель» на существующих контрактах `/api/*` (новых endpoint'ов нет).

**Сделано:**
- **RAG (#144):** запрос (SSE-стрим с источниками/цитатами), диалоговые чаты
  (список/деталь/история/task), алиасы TG-чатов, индекс (fixed/structure) и
  index-tg с предупреждением о reset, заметки (список/JSON-добавление/удаление).
- **Telegram (#145):** топ сообщений (сортировка реакции/дата), сбор (SSE-лог
  stage/progress), публикация (подтверждение, errorKind→русский), outbox-история,
  эволюция бота (SSE-чат с отменой).
- **Блог (#146):** блоги и настройки (PATCH с explicitNulls-семантикой сброса),
  посты (список/деталь/правка/удаление/publish с guard'ами), генерация по теме,
  news и scout (SSE), дайджест, стиль, пайплайн (sandbox-FSM), расписание (PUT
  целиком, идемпотентно).
- **MCP (#147):** список инструментов (configured/error-баннеры), вызов с
  локальной JSON-валидацией аргументов (не роняет экран).
- **Общая механика:** `SseParser` (generic) + `ArtelRepository.sseStream`
  (отмена/401 как в chatStream), тайлы дашборда «База знаний и каналы»,
  9 новых роутов навигации.
- **Сервер (блокер паритета):** 8 роутов с cookie-only `requireAuth` переведены
  на `requireApiAuth` (cookie ИЛИ Bearer): rag/index, rag/index-tg, rag/notes,
  summary POST, tg/collect, telegram/publish, blog posts/{id}/publish,
  blog digest/generate — мобильный клиент больше не получает 401 по valid-токену.

**Выводы:**
- SSE-ошибки приходят внутри 200-потока `{type:'error'}` — экраны обязаны
  парсить события, а не только HTTP-коды (отражено в парсерах).
- publish-эндпоинты не идемпотентны — guard от двойного тапа на клиенте.

**Код:** `android/app/src/main/java/ru/memo7/artel/{data/api/{Rag,Tg,Blog,Mcp,SseParser},ui/screens/{rag,tg,blog,mcp}}`,
`web/app/api/{rag,summary,tg,telegram,blog}` (requireApiAuth).
**Проверка:** `:app:testDebugUnitTest` 136/136 зелёных, `:app:assembleDebug` OK;
веб-тесты затронутых роутов зелёные.

---

## Execution loop run-2026-10-31 — Android parity wave 2: sys, integrations, chat extras
**Дата:** 2026-10-31
**Ветка:** `feat/close-open-issues`

**Задание:** стори #148–#150 эпика #134 — завершение паритета функций с web-админкой.

**Сделано:**
- **sys (#148):** агент (prompt≤8000, cloud/local), брифинг (10 счётчиков + top-TG,
  snake_case как на сервере), сводка (publishable + публикация с errorKind-маппингом
  и guard'ами), статусы серверов (mcp/cloud/local/embed/mtproto/botApi).
- **integrations (#149):** webhooks (список + доставки, создание с валидацией,
  удаление), inbound-хуки (создание с показом секрета ровно один раз — transient-стейт,
  не сохраняется и не логируется; удаление).
- **chat extras (#150):** шутник (SSE-стрим, температура 0.3..1.2, сброс, отмена),
  антонов (rewrite/thread, mode/format/llm, локальная валидация, 429/502/503 →
  русские строки), панели чата memory/branch/profile/constraints (bottom-sheet в
  ChatScreen, перезагрузка диалога после switch ветки).
- **Панель подключена в ChatScreen** (кнопка Tune → ModalBottomSheet) — чат MVP из
  #137 не регрессирует: его код не менялся кроме точки монтирования панели.
- Дашборд: секция «Система и инструменты» (sys/integrations/joker/antonov),
  8 новых роутов, +22 endpoint'а в ArtelApi, +24 delegate'а в репозитории.

**Выводы:**
- Контракт «секрет inbound показывается один раз» реализуем только transient-стейтом
  UI — в DataStore/логи он не попадает.
- requireApiAuth с wave 1 покрывает и новые write-операции (publish summary) —
  Bearer-сессия мобильного клиента проходит без cookie.

**Код:** `android/app/src/main/java/ru/memo7/artel/{data/api/{Sys,Integrations,ChatExtras,JokerSseParser},ui/screens/{sys,integrations,chatextras}}`,
`ui/screens/chat/ChatScreen.kt` (монтирование панели), `ui/{ArtelRoot,DashboardScreen}.kt`.
**Проверка:** `:app:testDebugUnitTest` 179/179 зелёных, `:app:assembleDebug` OK.

---

## Execution loop run-2026-11-01 — GPU-путь: локальное обучение на RX 7600 (ROCm TheRock)
**Дата:** 2026-11-01
**Ветка:** `feat/day07-dataset-v9`

**Задание:** эпик #186 — проверить и реализовать путь использования AMD RX 7600
(gfx1102, Windows) для рецептов day-06/07 (QLoRA NF4 через bitsandbytes),
которые ранее требовали Kaggle T4 (#179).

**Сделано:**
- Research опроверг исходную premise: bitsandbytes ≥0.49 поддерживает Windows +
  AMD RDNA gfx110X (QLoRA 4-bit ✅); TheRock (ROCm 7.14+) — gfx1102 на Windows
  Release Ready (✅/✅/✅). torch-directml — тупик (Sep 2024, pin torch 2.3.1,
  alpha); WSL2 ROCm — только gfx1100.
- **s1 (#183):** Python 3.12.10 + venv `training/.venv-rocm` (CPU-venv не
  тронут) + torch 2.14.0+rocm10.1.0 со stable-индекса TheRock
  (`torch[device-gfx1102]`, HIP 7.16.26385) + bnb 0.50.2/transformers 4.46.3/
  peft 0.21.2/datasets 3.1.0. Смоук `training/rocm/smoke_rocm.py`:
  `cuda_available=True`, device RX 7600, NF4 forward+backward ok.
- **s2 (#184):** прогон рецепта day-06 (скрипт не менялся, smoke-конфиг с
  срезами 200/40): train_loss 0.3129→0.1515, eval_loss 0.156, VRAM пик
  3.31 ГБ, ~6.9 с/шаг (T4 ~4.6 с/шаг), tokens/s ~970–1320; `paged_adamw_8bit`
  работает на ROCm. Экстраполяция полного рецепта: ~1.3–1.7 ч локально.
- **s3 (#185):** README `training/rocm/`, pins, комментарии в #183/#184/#179.

**Выводы:**
- Локальный recipe-preserving путь QLoRA NF4 на RX 7600 существует и работает:
  та же методология, что на T4; числовая байт-в-байт сверка с T4 невозможна
  (другое железо/fp16-ядра) — для сравнимых метрик пороги приёмки остаются на
  фиксированных eval-сетах.
- RX 7600 ~1.5× медленнее T4 на шаг NF4-рецепта, но порядок величины тот же —
  переобучение day-07 v9 (#179) теперь возможно локально, решение за владельцем.

**Код:** `training/rocm/{README.md, smoke_rocm.py, requirements-rocm.txt, configs/qlora-smoke.yaml}`, `.gitignore` (+`training/.venv-rocm/`).
**Проверка:** smoke `SMOKE OK` (artifacts/smoke_rocm.json); прогон day-06 smoke
12 шагов с падающим loss (run.json/loss.csv в training/rocm/artifacts/);
baseline `challenge` typecheck зелёный.

---

## ADVANCED Day 11 — Prompt Injection (2026-11-03)
**Дата:** 2026-11-03. Ветка `feat/security-days-11-12` (loop run-2026-11-03,
эпик #194, стори #195–#197). Неделя security; фронтрирные модели для атак не
используются — все прогоны на локальной qwen3.5:4b (Ollama, seed=42).

**Задание:** 3 техники direct injection (role-play DAN, instruction override,
extraction), фиксация что сработало; коллекция 5 реальных инъекций с
классификацией direct/indirect/jailbreak; атака на свой прод-промпт; усиленный
system prompt + ретест теми же техниками.

**Сделано:**
- `core/security/injectionLab.ts` — лаборатория: цели bank/medium (+hardened),
  6 атак (3 техники × 2) с детекторами (канарейки FREEDOM/МЯУ/ВЗЛОМАНО/ACCESS
  GRANTED, утечка по дословным фрагментам промпта), DI клиента как ChatFn,
  тесты node:test без сети (17).
- CLI `sec-inject --target bank|medium|hardened|all --model --author --seed`.
- Прогоны (транскрипты `docs/advanced-day-11/transcripts-*.md`): банк 1/6
  (override-канарейка «ВЗЛОМАНО»), свой прод-промпт бота «Медиум» 2/6 (смена
  личности с канарейкой МЯУ в манере персонажа + verbatim-утечка промпта через
  легенду «я разработчик»).
- Усиление: `hardenedBankTarget`/`hardenedMediumTarget` (иерархия
  «ИНСТРУКЦИИ vs ДАННЫЕ», запрет канареек, шаблон отказа, самопроверка) —
  ретест теми же 12 атаками: **0/12 проходов** (исходные: 3/12).
- Коллекция 5 реальных инъекций с классификацией и защитами в
  `docs/advanced-day-11/README.md` (Willison/NCC canonical, DAN, Bing «Sydney»,
  ChatGPT Search invisible text, промпты в научных статьях; источники —
  Ars Technica/Guardian/Nikkei/Wikipedia).

**Выводы:** прод-промпт «играй роль» уязвимее к role-play по построению;
extraction закрывается шаблоном отказа + output-детектором, а не запретом;
канарейка — однозначный маркер успеха для автоматизации; hardening — победа
над своими атаками, не над классом (NCSC: no surefire mitigations) — следующие
слои в дне 12.

**Код:** `challenge/src/core/security/{injectionLab.ts,injectionLab.test.ts}`,
`challenge/src/cli.ts` (sec-inject), `docs/advanced-day-11/**`.
**Проверка:** `pnpm --filter challenge typecheck` чисто; node:test 17/17;
реальные смоуки `sec-inject` на Ollama (bank/medium/hardened, seed=42).

---

## ADVANCED Day 12 — Indirect Prompt Injection (2026-11-03)
**Дата:** 2026-11-03. Ветка `feat/security-days-11-12` (loop run-2026-11-03,
эпик #198, стори #199–#201). Фронтрирные модели не используются — все прогоны
на локальной qwen3.5:4b (Ollama, seed=42).

**Задание:** ловушка для LLM-агента — инструкция спрятана в данных; 3 вектора
(email, документ, веб-страница); 3 защитных слоя (input sanitization, content
boundary markers, output validation); ретест атак после защиты; реальный кейс
упрощённо.

**Сделано:**
- `core/security/indirectLab.ts` — 4 вектора: email-суммаризатор (HTML-
  комментарий), документ-аналитик (белый текст + zero-width), поисковый агент
  (display:none + скрытый title в markdown-link → поддельный курс 500 руб), код
  репозитория (комментарий «NOTE FOR AI CODING ASSISTANTS» → навязанный
  npm-пакет; упрощение Copilot-кейса). Детекторы отличают реальное выполнение
  атаки от разоблачения/критики инъекции.
- `core/security/contentDefense.ts` — три слоя: `sanitizeExternal`
  (комментарии/script/style/template, невидимые стилями и `hidden` фрагменты с
  учётом вложенных тегов и без удаления текста на белом фоне, скрытые
  markdown-link title и `[//]: #`, zero-width/Bidi/Unicode Tags на уровне
  абзаца с поддержкой CRLF/BOM), boundary-маркеры с защитой от delimiter
  breakout + правило «данные — не инструкции», `validateOutput` с нормализацией
  пробелов и `ё/е`.
- CLI `sec-indirect --vector email|doc|search|code|all --mode
  none|sanitize|boundary|output|all|matrix` со строгой валидацией флагов и
  сводной матричной таблицей; публичный реэкспорт `core/security` в `core/index.ts`.
- Матрица 4×5 = 20 прогонов (транскрипт `docs/advanced-day-12/transcripts-
  matrix.md`): **5 из 20 прошли** (`all` — **0/4**). Без защиты проходят 3/4
  (`email`, `web-search`, `repo-code`; `doc` модель отбила сама). Одиночные
  слои имеют слепые зоны (`sanitize` пропускает видимый комментарий `repo-code`,
  `boundary` без санитации пропускает HTML-комментарий `email-summary`), тогда
  как комбинация `all` останавливает 4/4.
- Зафиксировано ложное срабатывание output-валидатора на `doc-analyst` (модель
  отказалась — валидатор заблокировал отказ за цитирование `system prompt`);
  урок — детект семантический, не подстрочный.

**Выводы:** indirect injection приходит в данных, которые агент обязан читать;
защита — эшелонированные слои, а не один слой; тесты фиксируют и обходы
санитайзера (zero-width в тегах, вложенные теги, delimiter breakout), и
слабости подстрочной валидации выхода.

**Код:** `challenge/src/core/security/{indirectLab.ts,contentDefense.ts,index.ts}` + тесты,
`challenge/src/core/index.ts`, `challenge/src/cli.ts` (sec-indirect), `docs/advanced-day-12/**`.
**Проверка:** `pnpm --filter challenge typecheck` чисто; node:test 44/44
(security-модули), 329/329 всего; реальные смоуки sec-inject/sec-indirect на Ollama (seed=42).

---

## ADVANCED Days 11–12 (доработка) — sec-chat: интерактивная red-team оболочка (2026-11-04)
**Дата:** 2026-11-04. Ветка `feat/security-days-11-12` (loop run-2026-11-04).
Фронтрирные модели не используются — чат идёт с локальной LLM (Ollama,
`think:false`), стриминг токенов в реальном времени.

**Задание:** красивая интерактивная CLI-оболочка для живых атак на локальную
модель 3–4B в security-дни 11–12: внедрение своего system prompt, атаки с
клавиатуры, и в реальном времени — классификация атаки, сработавшие детекторы
и вердикт.

**Сделано:**
- `core/security/redTeamChat.ts` (чистые функции): классификатор ввода по 7
  техникам (`extraction | override | canary | role-play | delimiter | encoding |
  social`) на статических паттернах RU/EN (без LLM-вызова, без новых
  зависимостей), эвристика извлечения канареек из текста атаки («начни со
  слова X» / "reply with exactly Y" / CAPS-слова), анализ ответа поверх
  детекторов дня 11 (`refuses`/`hasCanary`/`leaksSystemPrompt`), вердикт по
  словарю live-run: `ATTACK PASS` (маркер/утечка) · `DEFENSE HELD` (отказ) ·
  `AMBIGUOUS` (ответил без отказа — решает человек) · `DIALOG`, накопление
  статистики сессии. Тесты node:test (17).
- CLI `sec-chat --target bank|medium|hardened-bank|hardened-medium|custom
  --sys <text> --model --author --seed` (`challenge/src/secChat.ts`): панели
  banner → классификация (до ответа модели) → стриминг ответа с таймером →
  панель детекторов (канарейки/утечка/отказ) → цветной вердикт; слэш-команды с
  tab-дополнением: `/target`, `/sys show|set|file|reset`, `/canary
  list|<word>|rm`, `/attacks` (батарея 6 атак дня 11 против текущего промпта),
  `/stats`, `/history`, `/reset`, `/temp`, `/seed`, `/model`, `/export`;
  markdown-журнал сессии автосохраняется в `.data/redteam-journal-*.md`
  (транскрипт для docs/advanced-day-11/live-run.md §7).
- Публичный реэкспорт red-team API в `core/security/index.ts`.

**Выводы:** связка «классификация до генерации + детекторы после» даёт живую
петлю обучения без фронтрирных моделей; честный вердикт `AMBIGUOUS` важнее
агрессивного PASS — модель может подчиниться частично (ответить на вшитый
вопрос, не произнеся канарейку); захват канареек из текста атаки снимает
ручную регистрацию маркеров.

**Код:** `challenge/src/core/security/{redTeamChat.ts,redTeamChat.test.ts}`,
`challenge/src/secChat.ts`, `challenge/src/cli.ts` (sec-chat),
`challenge/src/core/security/index.ts`.
**Проверка:** `pnpm --filter challenge typecheck` чисто; node:test 346/346
всего (17 новых); смоуки: offline (`/help`, `/stats`, `/quit`) и живой прогон
на Ollama qwen3.5:4b (bank, seed=42) — DIALOG на benign-вопрос, классификация
`override + canary` и вердикт `AMBIGUOUS` на атаку, журнал записан.

---

## ADVANCED Days 11–12 (доработка 2) — sec-chat: коуч, кейсы и глоссарий (2026-11-04)
**Дата:** 2026-11-04. Ветка `feat/security-days-11-12` (loop run-2026-11-04,
issue #205). Только локальная LLM; фронтрирные модели не используются.

**Задание:** сделать оболочку максимально интерактивной: варианты system prompt,
библиотека реальных инъекций, подсказки «как атаковать», объяснение терминов
простыми словами и единый документ-сборник тест-кейсов.

**Сделано:**
- `core/security/redTeamCases.ts` (чистые данные/функции): 5 основных кейсов из
  открытых источников (ignore-the-above, DAN, Sydney, ChatGPT Search,
  peer-review) + 2 кейса дня 12 (Gemini memory, белый текст в резюме); у каждого
  — источник, механика, почему работает, защита, payload, канарейки, детектор,
  рекомендуемый промпт. 18 терминов глоссария (canary, почему FREEDOM, excess
  grant/excessive agency, boundary, sanitizer, output validation, verdict,
  over-refusal, crescendo, zero-width, RLHF и др.). 7 вариантов system prompt
  (`bank`, `medium`, `bank-hardened`, `medium-hardened`, `translator`,
  `reviewer`, `support`). Коуч `coachHint` + `topicHint` для подсказок по
  состоянию сессии и техникам.
- `sec-chat`: `/prompts` + `/prompt <id>` (совместимый `/target`), `/cases`,
  `/case <n>` (разбор), `/case <n> send` (payload в живой чат с авто-канарейками),
  `/learn [term]`, `/hint [topic]`; коуч-подсказка после каждого вердикта;
  обновлены banner/help/autocomplete. `findPromptVariant` заменил жёсткую карту
  целей в CLI, добавлены алиасы `hardened-bank`/`hardened-medium`.
- Классификатор `redTeamChat`: добавлены needle'ы `ignore the above`,
  `ignore previous`, `always recommend`, `do not tell the user` и др., чтобы
  payload'ы новых кейсов распознавались как атака.
- Документ [`docs/advanced-day-11/test-cases.md`](docs/advanced-day-11/test-cases.md):
  быстрый старт, глоссарий, 5+2 кейса, все 7 промптов, банк инъекций по
  техникам (direct/role-play/extraction/canary/delimiter/encoding/social/
  indirect), рубрика вердикта, журнал, границы безопасности. Ссылки из README
  дней 11 и 12.

**Выводы:** готовые кейсы снимают «страх пустого поля» — новичок запускает
`/case 1 send` и сразу видит классификацию, детекторы и вердикт; коуч после
каждого хода предлагает следующий шаг. Live-smoke выявил ограничение
эвристического детектора: модель может процитировать канарейку в рассуждении —
такой ответ стоит читать глазами и при сомнении ставить `AMBIGUOUS`.

**Код:** `challenge/src/core/security/{redTeamCases.ts,redTeamCases.test.ts,
redTeamChat.ts,index.ts}`, `challenge/src/secChat.ts`, `challenge/src/cli.ts`,
`docs/advanced-day-11/{test-cases.md,README.md}`, `docs/advanced-day-12/README.md`.
**Проверка:** `pnpm --filter challenge typecheck` чисто; node:test 359/359
(13 новых); offline-смоук `/cases`, `/case 1`, `/learn canary`, `/hint`,
`/prompts`; живой прогон на Ollama `qwen3:4b` (тега `qwen3.5:4b` в локальном
реестре не было; seed=42, temp=0) — `/case 1 send` на `translator`:
классификация `override`, канарейка `Haha pwned` найдена, вердикт
`ATTACK PASS`, журнал `.data/redteam-journal-*.md` записан.

---

## ADVANCED Days 11-12 - sec-demo: полный демо-прогон атак по дням (2026-11-04)
**Дата:** 2026-11-04. Ветка `feat/security-days-11-12`.
**Проблема:** атаки дня 11 и дня 12 запускались отдельными командами
(`sec-inject`, `sec-indirect`), а полного воспроизводимого демо-прогона
«все профили × все атаки» / «все векторы × все защиты» одной командой не было.

**Решение:** `core/security/securityDemo.ts` — оркестратор поверх готовых
лабораторий. Дни независимы:
- day-11: 4 профиля (`bank`, `medium`, `bank-hardened`, `medium-hardened`)
  × 6 direct-атак = 24 прогона; сводка по техникам и сравнение
  «исходные / усиленные».
- day-12: 4 indirect-вектора (email/doc/search/code) × 5 режимов
  (`none/sanitize/boundary/output/all`) = 20 прогонов; матрица и итог по
  режимам.
- CLI `sec-demo --day 11|12|all --model --author --seed` печатает полный
  транскрипт; `--day all` запускает оба дня, не смешивая их результаты.
- Клиент инжектится как `ChatFn`, поэтому node:test проверяет оркестрацию
  без сети (10 новых тестов).

**Выводы:** демо — воспроизводимый стенд, а не «слайд с цифрами»: один
прогон даёт все вердикты, сводки и матрицу. Цифры зависят от модели;
смоук для скорости — на `qwen2.5:0.5b-instruct` (seed=42): day-11 дал
12/24 (исходные 5/12, усиленные 7/12), day-12 — 2/20 при `all=0/4`.
Слабые модели хуже держат и усиленные промпты — это честно видно в
отчёте. Документированные прогоны README остаются на qwen3.5:4b.

**Код:** `challenge/src/core/security/{securityDemo.ts,securityDemo.test.ts,index.ts}`,
`challenge/src/cli.ts` (sec-demo), `docs/advanced-day-11/{README.md,live-run.md,test-cases.md}`,
`docs/advanced-day-12/{README.md,live-run.md}`.
**Проверка:** `pnpm --filter challenge typecheck` чисто; node:test 369/369
(10 новых); живой смоук `sec-demo --day 11` и `--day 12` на Ollama
`qwen2.5:0.5b-instruct` (seed=42) — оба дня отработали, транскрипты и
матрица напечатаны.

---

## ADVANCED Days 11-12 - sec-chat --auto: live-демо атак в чате (2026-11-04)
**Дата:** 2026-11-04. Ветка `feat/security-days-11-12`.
**Проблема:** `sec-demo` печатает всю батарею одним пакетом. Для показа нужен
живой чат: скрипт сам шлёт атаки по одной, меняет профиль и стримит ответ
модели — без ручного ввода.

**Решение:**
- `sec-chat --auto 11|12|all --pause <ms>` — автоматический live-режим.
  Для дня 11 скрипт открывает чат, шлёт 6 direct-атак на `bank`, затем меняет
  профиль на `medium`, `bank-hardened`, `medium-hardened` (24 хода). Для дня
  12 — 4 вектора × 5 режимов защиты (20 ходов): показывает данные, которые
  читает агент, payload-статус, стримит ответ и проверяет output-валидатор.
- `runTurn` теперь возвращает `{ response, analysis, verdict }` и умеет
  отключать авто-сбор канареек (`collectCanaries: false`) — в live-демо
  детекторы показывают только релевантные маркеры, без мусора из boundary-
  разметки.
- `prepareIndirectPrompt` вынесен из `runIndirectAttack` в `indirectLab.ts`
  и переиспользуется live-чатом: один источник истины для слоёв
  sanitize/boundary/output.
- Добавлены чистые `day11ChatSteps()` / `day12ChatSteps()` — порядок ходов
  live-демо и 2 новых теста; `sec-chat --auto` проверен на обоих днях.

**Выводы:** live-режим — это тот же чат `sec-chat`, но без hand-ввода: видно,
как атака приходит по одной, как меняется профиль и как модель отвечает в
реальном времени. Батч `sec-demo` остаётся для быстрых сводок, live-режим —
для показа.

**Код:** `challenge/src/core/security/{securityDemo.ts,securityDemo.test.ts,
indirectLab.ts,index.ts}`, `challenge/src/secChat.ts`, `challenge/src/cli.ts`,
`docs/advanced-day-11/{README.md,live-run.md,test-cases.md}`,
`docs/advanced-day-12/{README.md,live-run.md}`.
**Проверка:** `pnpm --filter challenge typecheck` чисто; node:test 371/371
(2 новых); live-смоук `sec-chat --auto 11` (24 хода) и `--auto 12` (20 ходов)
на Ollama `qwen2.5:0.5b-instruct` (seed=42, pause=50) — стрим, детекторы и
журналы `.data/redteam-journal-*.md` отработали.
